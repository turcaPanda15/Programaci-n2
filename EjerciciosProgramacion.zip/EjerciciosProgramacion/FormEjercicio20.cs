﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio20 : Form
    {
        public FormEjercicio20()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el número ingresado
                int numero = int.Parse(txtNumero.Text);

                // Verificar si es par o impar
                if (numero % 2 == 0)
                {
                    lblResultado.Text = "El número es par.";
                }
                else
                {
                    lblResultado.Text = "El número es impar.";
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
