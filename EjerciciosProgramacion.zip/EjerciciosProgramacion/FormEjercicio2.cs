﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio2 : Form
    {
        public FormEjercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el radio del círculo
                double radio = double.Parse(txtRadio.Text);

                // Calcular el perímetro del círculo
                double perimetro = 2 * Math.PI * radio;

                // Calcular el área del círculo
                double area = Math.PI * Math.Pow(radio, 2);

                // Mostrar el resultado
                lblResultado.Text = $"Perímetro: {perimetro:F2}\nÁrea: {area:F2}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un valor numérico válido para el radio del círculo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    
    }
}
