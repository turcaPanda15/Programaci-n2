﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio1 : Form
    {
        public FormEjercicio1()
        {
            InitializeComponent();
        }
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener la base y la altura del rectángulo
                double baseRectangulo = double.Parse(txtBase.Text);
                double alturaRectangulo = double.Parse(txtAltura.Text);

                // Calcular el área del rectángulo
                double areaRectangulo = baseRectangulo * alturaRectangulo;

                // Mostrar el resultado
                lblResultado.Text = $"Base: {baseRectangulo}\nAltura: {alturaRectangulo}\nÁrea: {areaRectangulo}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos para la base y la altura del rectángulo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
