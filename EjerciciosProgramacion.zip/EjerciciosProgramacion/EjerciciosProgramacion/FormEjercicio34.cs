﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio34 : Form
    {
        public FormEjercicio34()
        {
            InitializeComponent();
        }

        private void btnLeer_Click(object sender, EventArgs e)
        {
            try
            {
                int cantidad = int.Parse(txtCantidad.Text);
                int[] numeros = new int[cantidad];
                for (int i = 0; i < cantidad; i++)
                {
                    string input = Microsoft.VisualBasic.Interaction.InputBox($"Ingrese el número {i + 1}:", "Entrada de Números", "0");
                    if (int.TryParse(input, out int numero))
                    {
                        numeros[i] = numero;
                    }
                    else
                    {
                        MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        i--; // Volver a pedir el número si no es válido
                    }
                }
                txtNumeros.Clear();
                foreach (int numero in numeros)
                {
                    txtNumeros.AppendText(numero + Environment.NewLine);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese una cantidad válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
