﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio51 : Form
    {
        public FormEjercicio51()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            // Obtener el número ingresado por el usuario
            int numero = int.Parse(txtNumero.Text);

            // Verificar si el número es primo
            bool esPrimo = EsPrimo(numero);

            // Mostrar el resultado
            if (esPrimo)
            {
                txtResultado.Text = numero + " es un número primo.";
            }
            else
            {
                txtResultado.Text = numero + " no es un número primo.";
            }
        }

        private bool EsPrimo(int numero)
        {
            if (numero <= 1)
            {
                return false;
            }
            for (int i = 2; i <= Math.Sqrt(numero); i++)
            {
                if (numero % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
