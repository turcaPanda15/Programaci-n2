﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio37
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.btnIngresarNumeros = new System.Windows.Forms.Button();
            this.lstNumeros = new System.Windows.Forms.ListBox();
            this.lblPares = new System.Windows.Forms.Label();
            this.lblImpares = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(50, 20);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(310, 28);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Contar Números Pares e Impares";
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.Location = new System.Drawing.Point(50, 70);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(167, 20);
            this.lblCantidad.TabIndex = 1;
            this.lblCantidad.Text = "Cantidad de Números (n):";
            // 
            // txtCantidad
            // 
            this.txtCantidad.Location = new System.Drawing.Point(230, 67);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(100, 27);
            this.txtCantidad.TabIndex = 2;
            // 
            // btnIngresarNumeros
            // 
            this.btnIngresarNumeros.Location = new System.Drawing.Point(340, 65);
            this.btnIngresarNumeros.Name = "btnIngresarNumeros";
            this.btnIngresarNumeros.Size = new System.Drawing.Size(75, 30);
            this.btnIngresarNumeros.TabIndex = 3;
            this.btnIngresarNumeros.Text = "Ingresar";
            this.btnIngresarNumeros.UseVisualStyleBackColor = true;
            this.btnIngresarNumeros.Click += new System.EventHandler(this.btnIngresarNumeros_Click);
            // 
            // lstNumeros
            // 
            this.lstNumeros.FormattingEnabled = true;
            this.lstNumeros.ItemHeight = 20;
            this.lstNumeros.Location = new System.Drawing.Point(50, 110);
            this.lstNumeros.Name = "lstNumeros";
            this.lstNumeros.Size = new System.Drawing.Size(200, 204);
            this.lstNumeros.TabIndex = 4;
            // 
            // lblPares
            // 
            this.lblPares.AutoSize = true;
            this.lblPares.Location = new System.Drawing.Point(270, 160);
            this.lblPares.Name = "lblPares";
            this.lblPares.Size = new System.Drawing.Size(109, 20);
            this.lblPares.TabIndex = 5;
            this.lblPares.Text = "Números Pares:";
            // 
            // lblImpares
            // 
            this.lblImpares.AutoSize = true;
            this.lblImpares.Location = new System.Drawing.Point(270, 200);
            this.lblImpares.Name = "lblImpares";
            this.lblImpares.Size = new System.Drawing.Size(124, 20);
            this.lblImpares.TabIndex = 6;
            this.lblImpares.Text = "Números Impares:";
            // 
            // FormEjercicio37
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 400);
            this.Controls.Add(this.lblImpares);
            this.Controls.Add(this.lblPares);
            this.Controls.Add(this.lstNumeros);
            this.Controls.Add(this.btnIngresarNumeros);
            this.Controls.Add(this.txtCantidad);
            this.Controls.Add(this.lblCantidad);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormEjercicio37";
            this.Text = "Contar Números Pares e Impares";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.TextBox txtCantidad;
        private System.Windows.Forms.Button btnIngresarNumeros;
        private System.Windows.Forms.ListBox lstNumeros;
        private System.Windows.Forms.Label lblPares;
        private System.Windows.Forms.Label lblImpares;
    }
}
