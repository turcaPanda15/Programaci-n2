﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio60
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblPregunta = new Label();
            txtRespuesta = new TextBox();
            btnResponder = new Button();
            SuspendLayout();
            // 
            // lblPregunta
            // 
            lblPregunta.AutoSize = true;
            lblPregunta.Location = new Point(11, 15);
            lblPregunta.Name = "lblPregunta";
            lblPregunta.Size = new Size(306, 20);
            lblPregunta.TabIndex = 0;
            lblPregunta.Text = "¿Cuál es la capital del folclore nicaragüense?";
            // 
            // txtRespuesta
            // 
            txtRespuesta.Location = new Point(59, 38);
            txtRespuesta.Name = "txtRespuesta";
            txtRespuesta.Size = new Size(212, 27);
            txtRespuesta.TabIndex = 1;
            // 
            // btnResponder
            // 
            btnResponder.Location = new Point(59, 86);
            btnResponder.Name = "btnResponder";
            btnResponder.Size = new Size(212, 35);
            btnResponder.TabIndex = 2;
            btnResponder.Text = "Responder";
            btnResponder.UseVisualStyleBackColor = true;
            btnResponder.Click += btnResponder_Click;
            // 
            // FormEjercicio60
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(344, 153);
            Controls.Add(btnResponder);
            Controls.Add(txtRespuesta);
            Controls.Add(lblPregunta);
            Name = "FormEjercicio60";
            Text = "Adivinanza";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblPregunta;
        private System.Windows.Forms.TextBox txtRespuesta;
        private System.Windows.Forms.Button btnResponder;
    }
}
