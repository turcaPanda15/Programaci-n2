﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio59
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblNumero = new Label();
            txtNumero = new TextBox();
            btnVerificar = new Button();
            lblResultado = new Label();
            txtResultado = new TextBox();
            SuspendLayout();
            // 
            // lblNumero
            // 
            lblNumero.AutoSize = true;
            lblNumero.Location = new Point(11, 15);
            lblNumero.Name = "lblNumero";
            lblNumero.Size = new Size(135, 20);
            lblNumero.TabIndex = 0;
            lblNumero.Text = "Ingrese un número:";
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(152, 12);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(178, 27);
            txtNumero.TabIndex = 1;
            // 
            // btnVerificar
            // 
            btnVerificar.Location = new Point(54, 45);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(285, 35);
            btnVerificar.TabIndex = 2;
            btnVerificar.Text = "Verificar si es perfecto";
            btnVerificar.UseVisualStyleBackColor = true;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(11, 105);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(78, 20);
            lblResultado.TabIndex = 3;
            lblResultado.Text = "Resultado:";
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(118, 102);
            txtResultado.Name = "txtResultado";
            txtResultado.ReadOnly = true;
            txtResultado.Size = new Size(178, 27);
            txtResultado.TabIndex = 4;
            // 
            // FormEjercicio59
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(376, 153);
            Controls.Add(txtResultado);
            Controls.Add(lblResultado);
            Controls.Add(btnVerificar);
            Controls.Add(txtNumero);
            Controls.Add(lblNumero);
            Name = "FormEjercicio59";
            Text = "FormEjercicio59";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtResultado;
    }
}
