﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio27
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblPantalones = new System.Windows.Forms.Label();
            this.txtPantalones = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblCostoTotal = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(111, 28);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(238, 28);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Costo Total de Pantalones";
            // 
            // lblPantalones
            // 
            this.lblPantalones.AutoSize = true;
            this.lblPantalones.Location = new System.Drawing.Point(25, 81);
            this.lblPantalones.Name = "lblPantalones";
            this.lblPantalones.Size = new System.Drawing.Size(94, 20);
            this.lblPantalones.TabIndex = 1;
            this.lblPantalones.Text = "Pantalones:";
            // 
            // txtPantalones
            // 
            this.txtPantalones.Location = new System.Drawing.Point(129, 78);
            this.txtPantalones.Name = "txtPantalones";
            this.txtPantalones.Size = new System.Drawing.Size(100, 27);
            this.txtPantalones.TabIndex = 2;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(129, 124);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(100, 29);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblCostoTotal
            // 
            this.lblCostoTotal.AutoSize = true;
            this.lblCostoTotal.Location = new System.Drawing.Point(25, 177);
            this.lblCostoTotal.Name = "lblCostoTotal";
            this.lblCostoTotal.Size = new System.Drawing.Size(0, 20);
            this.lblCostoTotal.TabIndex = 4;
            // 
            // FormEjercicio27
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 305);
            this.Controls.Add(this.lblCostoTotal);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtPantalones);
            this.Controls.Add(this.lblPantalones);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormEjercicio27";
            this.Text = "Costo Total de Pantalones";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblPantalones;
        private System.Windows.Forms.TextBox txtPantalones;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblCostoTotal;
    }
}
