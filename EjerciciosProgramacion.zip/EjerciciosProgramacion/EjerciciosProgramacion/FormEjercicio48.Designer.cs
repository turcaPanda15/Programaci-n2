﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio48
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatriz = new System.Windows.Forms.TextBox();
            this.txtResultadoA = new System.Windows.Forms.TextBox();
            this.txtResultadoB = new System.Windows.Forms.TextBox();
            this.txtResultadoC = new System.Windows.Forms.TextBox();
            this.txtResultadoD = new System.Windows.Forms.TextBox();
            this.btnImprimir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtMatriz
            // 
            this.txtMatriz.Location = new System.Drawing.Point(12, 12);
            this.txtMatriz.Multiline = true;
            this.txtMatriz.Name = "txtMatriz";
            this.txtMatriz.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtMatriz.Size = new System.Drawing.Size(300, 200);
            this.txtMatriz.TabIndex = 0;
            // 
            // txtResultadoA
            // 
            this.txtResultadoA.Location = new System.Drawing.Point(332, 12);
            this.txtResultadoA.Multiline = true;
            this.txtResultadoA.Name = "txtResultadoA";
            this.txtResultadoA.ReadOnly = true;
            this.txtResultadoA.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResultadoA.Size = new System.Drawing.Size(300, 200);
            this.txtResultadoA.TabIndex = 1;
            // 
            // txtResultadoB
            // 
            this.txtResultadoB.Location = new System.Drawing.Point(12, 232);
            this.txtResultadoB.Multiline = true;
            this.txtResultadoB.Name = "txtResultadoB";
            this.txtResultadoB.ReadOnly = true;
            this.txtResultadoB.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResultadoB.Size = new System.Drawing.Size(300, 200);
            this.txtResultadoB.TabIndex = 2;
            // 
            // txtResultadoC
            // 
            this.txtResultadoC.Location = new System.Drawing.Point(332, 232);
            this.txtResultadoC.Multiline = true;
            this.txtResultadoC.Name = "txtResultadoC";
            this.txtResultadoC.ReadOnly = true;
            this.txtResultadoC.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResultadoC.Size = new System.Drawing.Size(300, 200);
            this.txtResultadoC.TabIndex = 3;
            // 
            // txtResultadoD
            // 
            this.txtResultadoD.Location = new System.Drawing.Point(12, 452);
            this.txtResultadoD.Multiline = true;
            this.txtResultadoD.Name = "txtResultadoD";
            this.txtResultadoD.ReadOnly = true;
            this.txtResultadoD.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResultadoD.Size = new System.Drawing.Size(620, 200);
            this.txtResultadoD.TabIndex = 4;
            // 
            // btnImprimir
            // 
            this.btnImprimir.Location = new System.Drawing.Point(12, 658);
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(620, 35);
            this.btnImprimir.TabIndex = 5;
            this.btnImprimir.Text = "Imprimir";
            this.btnImprimir.UseVisualStyleBackColor = true;
            this.btnImprimir.Click += new System.EventHandler(this.btnImprimir_Click);
            // 
            // FormEjercicio48
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 705);
            this.Controls.Add(this.btnImprimir);
            this.Controls.Add(this.txtResultadoD);
            this.Controls.Add(this.txtResultadoC);
            this.Controls.Add(this.txtResultadoB);
            this.Controls.Add(this.txtResultadoA);
            this.Controls.Add(this.txtMatriz);
            this.Name = "FormEjercicio48";
            this.Text = "FormEjercicio48";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatriz;
        private System.Windows.Forms.TextBox txtResultadoA;
        private System.Windows.Forms.TextBox txtResultadoB;
        private System.Windows.Forms.TextBox txtResultadoC;
        private System.Windows.Forms.TextBox txtResultadoD;
        private System.Windows.Forms.Button btnImprimir;
    }
}
