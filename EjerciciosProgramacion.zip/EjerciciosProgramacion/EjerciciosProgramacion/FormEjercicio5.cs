﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio5 : Form
    {
        public FormEjercicio5()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los números ingresados
                double num1 = double.Parse(txtNumero1.Text);
                double num2 = double.Parse(txtNumero2.Text);
                double num3 = double.Parse(txtNumero3.Text);

                // Calcular el promedio
                double promedio = (num1 + num2 + num3) / 3;

                // Mostrar el resultado
                lblResultado.Text = $"El promedio de {num1}, {num2} y {num3} es {promedio:F2}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
