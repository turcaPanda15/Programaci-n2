﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio62 : Form
    {
        public FormEjercicio62()
        {
            InitializeComponent();
        }

        private void btnEncontrarPerfectos_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int numero = 1;

            txtResultado.Text = "Los primeros tres números perfectos son:\r\n";

            while (contador < 3)
            {
                if (EsNumeroPerfecto(numero))
                {
                    txtResultado.Text += $"{numero}\r\n";
                    contador++;
                }
                numero++;
            }
        }

        private bool EsNumeroPerfecto(int numero)
        {
            int sumaDivisores = 0;
            for (int i = 1; i < numero; i++)
            {
                if (numero % i == 0)
                {
                    sumaDivisores += i;
                }
            }
            return sumaDivisores == numero;
        }
    }
}
