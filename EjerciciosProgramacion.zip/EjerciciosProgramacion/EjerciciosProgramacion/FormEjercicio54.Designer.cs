﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio54
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumeros = new Label();
            txtNumeros = new TextBox();
            btnCalcular = new Button();
            lblMedia = new Label();
            txtMedia = new TextBox();
            SuspendLayout();
            // 
            // lblNumeros
            // 
            lblNumeros.AutoSize = true;
            lblNumeros.Location = new Point(11, 15);
            lblNumeros.Name = "lblNumeros";
            lblNumeros.Size = new Size(304, 20);
            lblNumeros.TabIndex = 0;
            lblNumeros.Text = "Ingrese los números separados por espacios:";
            // 
            // txtNumeros
            // 
            txtNumeros.Location = new Point(321, 15);
            txtNumeros.Name = "txtNumeros";
            txtNumeros.Size = new Size(356, 27);
            txtNumeros.TabIndex = 1;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(62, 48);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(528, 35);
            btnCalcular.TabIndex = 2;
            btnCalcular.Text = "Calcular Media";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblMedia
            // 
            lblMedia.AutoSize = true;
            lblMedia.Location = new Point(11, 105);
            lblMedia.Name = "lblMedia";
            lblMedia.Size = new Size(54, 20);
            lblMedia.TabIndex = 3;
            lblMedia.Text = "Media:";
            // 
            // txtMedia
            // 
            txtMedia.Location = new Point(62, 102);
            txtMedia.Name = "txtMedia";
            txtMedia.ReadOnly = true;
            txtMedia.Size = new Size(89, 27);
            txtMedia.TabIndex = 4;
            // 
            // FormEjercicio54
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(692, 153);
            Controls.Add(txtMedia);
            Controls.Add(lblMedia);
            Controls.Add(btnCalcular);
            Controls.Add(txtNumeros);
            Controls.Add(lblNumeros);
            Name = "FormEjercicio54";
            Text = "FormEjercicio54";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblNumeros;
        private System.Windows.Forms.TextBox txtNumeros;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblMedia;
        private System.Windows.Forms.TextBox txtMedia;
    }
}
