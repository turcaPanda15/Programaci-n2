﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio6 : Form
    {
        public FormEjercicio6()
        {
            InitializeComponent();
        }

        private void btnConvertir_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los kilogramos ingresados
                double kilogramos = double.Parse(txtKilogramos.Text);

                // Convertir kilogramos a libras
                double libras = kilogramos * 2.20462;

                // Mostrar el resultado
                lblResultado.Text = $"{kilogramos} kilogramos equivalen a {libras:F2} libras";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un valor numérico válido para los kilogramos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
