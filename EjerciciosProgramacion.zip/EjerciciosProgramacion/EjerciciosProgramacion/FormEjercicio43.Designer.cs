﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio43
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.btnCalcularPromedio = new System.Windows.Forms.Button();
            this.lstPromedios = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnCalcularPromedio
            // 
            this.btnCalcularPromedio.Location = new System.Drawing.Point(50, 20);
            this.btnCalcularPromedio.Name = "btnCalcularPromedio";
            this.btnCalcularPromedio.Size = new System.Drawing.Size(200, 30);
            this.btnCalcularPromedio.TabIndex = 0;
            this.btnCalcularPromedio.Text = "Calcular Promedio";
            this.btnCalcularPromedio.UseVisualStyleBackColor = true;
            this.btnCalcularPromedio.Click += new System.EventHandler(this.btnCalcularPromedio_Click);
            // 
            // lstPromedios
            // 
            this.lstPromedios.FormattingEnabled = true;
            this.lstPromedios.ItemHeight = 21;
            this.lstPromedios.Location = new System.Drawing.Point(50, 70);
            this.lstPromedios.Name = "lstPromedios";
            this.lstPromedios.Size = new System.Drawing.Size(300, 235);
            this.lstPromedios.TabIndex = 1;
            // 
            // FormEjercicio43
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 350);
            this.Controls.Add(this.lstPromedios);
            this.Controls.Add(this.btnCalcularPromedio);
            this.Name = "FormEjercicio43";
            this.Text = "Calcular Promedio de Estudiantes";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCalcularPromedio;
        private System.Windows.Forms.ListBox lstPromedios;
    }
}
