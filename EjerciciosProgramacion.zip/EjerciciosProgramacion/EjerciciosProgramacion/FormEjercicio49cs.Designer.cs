﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio49
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatrizA = new System.Windows.Forms.TextBox();
            this.txtMatrizB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtResultadoAB = new System.Windows.Forms.TextBox();
            this.txtResultado2A_3B = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtMatrizA
            // 
            this.txtMatrizA.Location = new System.Drawing.Point(96, 12);
            this.txtMatrizA.Multiline = true;
            this.txtMatrizA.Name = "txtMatrizA";
            this.txtMatrizA.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtMatrizA.Size = new System.Drawing.Size(200, 150);
            this.txtMatrizA.TabIndex = 0;
            // 
            // txtMatrizB
            // 
            this.txtMatrizB.Location = new System.Drawing.Point(96, 168);
            this.txtMatrizB.Multiline = true;
            this.txtMatrizB.Name = "txtMatrizB";
            this.txtMatrizB.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtMatrizB.Size = new System.Drawing.Size(200, 150);
            this.txtMatrizB.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Matriz A:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Matriz B:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(16, 332);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(280, 35);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtResultadoAB
            // 
            this.txtResultadoAB.Location = new System.Drawing.Point(372, 12);
            this.txtResultadoAB.Multiline = true;
            this.txtResultadoAB.Name = "txtResultadoAB";
            this.txtResultadoAB.ReadOnly = true;
            this.txtResultadoAB.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResultadoAB.Size = new System.Drawing.Size(200, 150);
            this.txtResultadoAB.TabIndex = 5;
            // 
            // txtResultado2A_3B
            // 
            this.txtResultado2A_3B.Location = new System.Drawing.Point(372, 168);
            this.txtResultado2A_3B.Multiline = true;
            this.txtResultado2A_3B.Name = "txtResultado2A_3B";
            this.txtResultado2A_3B.ReadOnly = true;
            this.txtResultado2A_3B.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResultado2A_3B.Size = new System.Drawing.Size(200, 150);
            this.txtResultado2A_3B.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(317, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Resultado A+B:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(317, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Resultado 2A+3B:";
            // 
            // FormEjercicio49
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 379);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtResultado2A_3B);
            this.Controls.Add(this.txtResultadoAB);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMatrizB);
            this.Controls.Add(this.txtMatrizA);
            this.Name = "FormEjercicio49";
            this.Text = "FormEjercicio49";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatrizA;
        private System.Windows.Forms.TextBox txtMatrizB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtResultadoAB;
        private System.Windows.Forms.TextBox txtResultado2A_3B;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}
