﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio52
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumeros = new System.Windows.Forms.Label();
            this.txtNumeros = new System.Windows.Forms.TextBox();
            this.btnContar = new System.Windows.Forms.Button();
            this.lblPositivos = new System.Windows.Forms.Label();
            this.lblNegativos = new System.Windows.Forms.Label();
            this.lblCeros = new System.Windows.Forms.Label();
            this.txtPositivos = new System.Windows.Forms.TextBox();
            this.txtNegativos = new System.Windows.Forms.TextBox();
            this.txtCeros = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNumeros
            // 
            this.lblNumeros.AutoSize = true;
            this.lblNumeros.Location = new System.Drawing.Point(12, 15);
            this.lblNumeros.Name = "lblNumeros";
            this.lblNumeros.Size = new System.Drawing.Size(188, 20);
            this.lblNumeros.TabIndex = 0;
            this.lblNumeros.Text = "Ingrese 20 números separados por espacio:";
            // 
            // txtNumeros
            // 
            this.txtNumeros.Location = new System.Drawing.Point(206, 12);
            this.txtNumeros.Name = "txtNumeros";
            this.txtNumeros.Size = new System.Drawing.Size(400, 27);
            this.txtNumeros.TabIndex = 1;
            // 
            // btnContar
            // 
            this.btnContar.Location = new System.Drawing.Point(12, 53);
            this.btnContar.Name = "btnContar";
            this.btnContar.Size = new System.Drawing.Size(594, 35);
            this.btnContar.TabIndex = 2;
            this.btnContar.Text = "Contar";
            this.btnContar.UseVisualStyleBackColor = true;
            this.btnContar.Click += new System.EventHandler(this.btnContar_Click);
            // 
            // lblPositivos
            // 
            this.lblPositivos.AutoSize = true;
            this.lblPositivos.Location = new System.Drawing.Point(12, 105);
            this.lblPositivos.Name = "lblPositivos";
            this.lblPositivos.Size = new System.Drawing.Size(65, 20);
            this.lblPositivos.TabIndex = 3;
            this.lblPositivos.Text = "Positivos:";
            // 
            // lblNegativos
            // 
            this.lblNegativos.AutoSize = true;
            this.lblNegativos.Location = new System.Drawing.Point(12, 145);
            this.lblNegativos.Name = "lblNegativos";
            this.lblNegativos.Size = new System.Drawing.Size(71, 20);
            this.lblNegativos.TabIndex = 4;
            this.lblNegativos.Text = "Negativos:";
            // 
            // lblCeros
            // 
            this.lblCeros.AutoSize = true;
            this.lblCeros.Location = new System.Drawing.Point(12, 185);
            this.lblCeros.Name = "lblCeros";
            this.lblCeros.Size = new System.Drawing.Size(43, 20);
            this.lblCeros.TabIndex = 5;
            this.lblCeros.Text = "Ceros:";
            // 
            // txtPositivos
            // 
            this.txtPositivos.Location = new System.Drawing.Point(93, 102);
            this.txtPositivos.Name = "txtPositivos";
            this.txtPositivos.ReadOnly = true;
            this.txtPositivos.Size = new System.Drawing.Size(100, 27);
            this.txtPositivos.TabIndex = 6;
            // 
            // txtNegativos
            // 
            this.txtNegativos.Location = new System.Drawing.Point(93, 142);
            this.txtNegativos.Name = "txtNegativos";
            this.txtNegativos.ReadOnly = true;
            this.txtNegativos.Size = new System.Drawing.Size(100, 27);
            this.txtNegativos.TabIndex = 7;
            // 
            // txtCeros
            // 
            this.txtCeros.Location = new System.Drawing.Point(93, 182);
            this.txtCeros.Name = "txtCeros";
            this.txtCeros.ReadOnly = true;
            this.txtCeros.Size = new System.Drawing.Size(100, 27);
            this.txtCeros.TabIndex = 8;
            // 
            // FormEjercicio52
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 224);
            this.Controls.Add(this.txtCeros);
            this.Controls.Add(this.txtNegativos);
            this.Controls.Add(this.txtPositivos);
            this.Controls.Add(this.lblCeros);
            this.Controls.Add(this.lblNegativos);
            this.Controls.Add(this.lblPositivos);
            this.Controls.Add(this.btnContar);
            this.Controls.Add(this.txtNumeros);
            this.Controls.Add(this.lblNumeros);
            this.Name = "FormEjercicio52";
            this.Text = "FormEjercicio52";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumeros;
        private System.Windows.Forms.TextBox txtNumeros;
        private System.Windows.Forms.Button btnContar;
        private System.Windows.Forms.Label lblPositivos;
        private System.Windows.Forms.Label lblNegativos;
        private System.Windows.Forms.Label lblCeros;
        private System.Windows.Forms.TextBox txtPositivos;
        private System.Windows.Forms.TextBox txtNegativos;
        private System.Windows.Forms.TextBox txtCeros;
    }
}
