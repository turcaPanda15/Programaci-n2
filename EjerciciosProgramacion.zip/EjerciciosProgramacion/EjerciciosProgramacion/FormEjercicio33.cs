﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio33 : Form
    {
        public FormEjercicio33()
        {
            InitializeComponent();
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            txtNumeros.Clear();
            for (int i = 1; i <= 100; i++)
            {
                txtNumeros.AppendText(i + Environment.NewLine);
            }
        }
    }
}
