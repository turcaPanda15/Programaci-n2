﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio38 : Form
    {
        public FormEjercicio38()
        {
            InitializeComponent();
            CalcularNumerosImparesYSuma();
        }

        private void CalcularNumerosImparesYSuma()
        {
            int contadorImpares = 0;
            int sumaImpares = 0;

            for (int i = 21; i <= 100; i += 2)
            {
                contadorImpares++;
                sumaImpares += i;
            }

            lblResultados.Text += $"Hay {contadorImpares} números impares entre 20 y 100. La suma de estos números es {sumaImpares}.";
        }
    }
}
