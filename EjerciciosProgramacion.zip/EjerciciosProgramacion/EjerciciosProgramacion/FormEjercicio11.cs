﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio11 : Form
    {
        public FormEjercicio11()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el número ingresado
                double numero = double.Parse(txtNumero.Text);

                // Calcular el coseno del número
                double coseno = Math.Cos(numero);

                // Mostrar el resultado
                lblResultado.Text = $"El coseno de {numero} es {coseno:F2}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un valor numérico válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
