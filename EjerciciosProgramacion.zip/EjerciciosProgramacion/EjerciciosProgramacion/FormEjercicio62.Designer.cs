﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio62
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnEncontrarPerfectos = new Button();
            txtResultado = new TextBox();
            lblResultado = new Label();
            SuspendLayout();
            // 
            // btnEncontrarPerfectos
            // 
            btnEncontrarPerfectos.Location = new Point(50, 12);
            btnEncontrarPerfectos.Name = "btnEncontrarPerfectos";
            btnEncontrarPerfectos.Size = new Size(190, 35);
            btnEncontrarPerfectos.TabIndex = 0;
            btnEncontrarPerfectos.Text = "Encontrar Números Perfectos";
            btnEncontrarPerfectos.UseVisualStyleBackColor = true;
            btnEncontrarPerfectos.Click += btnEncontrarPerfectos_Click;
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(49, 70);
            txtResultado.Multiline = true;
            txtResultado.Name = "txtResultado";
            txtResultado.ReadOnly = true;
            txtResultado.ScrollBars = ScrollBars.Vertical;
            txtResultado.Size = new Size(191, 124);
            txtResultado.TabIndex = 1;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(11, 47);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(78, 20);
            lblResultado.TabIndex = 2;
            lblResultado.Text = "Resultado:";
            // 
            // FormEjercicio62
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(304, 206);
            Controls.Add(lblResultado);
            Controls.Add(txtResultado);
            Controls.Add(btnEncontrarPerfectos);
            Name = "FormEjercicio62";
            Text = "FormEjercicio62";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Button btnEncontrarPerfectos;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Label lblResultado;
    }
}
