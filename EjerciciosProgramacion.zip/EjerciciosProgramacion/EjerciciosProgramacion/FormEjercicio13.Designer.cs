﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio13
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblYardas = new System.Windows.Forms.Label();
            this.txtYardas = new System.Windows.Forms.TextBox();
            this.lblPies = new System.Windows.Forms.Label();
            this.txtPies = new System.Windows.Forms.TextBox();
            this.lblPulgadas = new System.Windows.Forms.Label();
            this.txtPulgadas = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(115, 29);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(309, 28);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Convertir Yardas, Pies y Pulgadas";
            // 
            // lblYardas
            // 
            this.lblYardas.AutoSize = true;
            this.lblYardas.Location = new System.Drawing.Point(48, 83);
            this.lblYardas.Name = "lblYardas";
            this.lblYardas.Size = new System.Drawing.Size(59, 20);
            this.lblYardas.TabIndex = 1;
            this.lblYardas.Text = "Yardas:";
            // 
            // txtYardas
            // 
            this.txtYardas.Location = new System.Drawing.Point(113, 80);
            this.txtYardas.Name = "txtYardas";
            this.txtYardas.Size = new System.Drawing.Size(100, 27);
            this.txtYardas.TabIndex = 2;
            // 
            // lblPies
            // 
            this.lblPies.AutoSize = true;
            this.lblPies.Location = new System.Drawing.Point(48, 130);
            this.lblPies.Name = "lblPies";
            this.lblPies.Size = new System.Drawing.Size(38, 20);
            this.lblPies.TabIndex = 3;
            this.lblPies.Text = "Pies:";
            // 
            // txtPies
            // 
            this.txtPies.Location = new System.Drawing.Point(113, 127);
            this.txtPies.Name = "txtPies";
            this.txtPies.Size = new System.Drawing.Size(100, 27);
            this.txtPies.TabIndex = 4;
            // 
            // lblPulgadas
            // 
            this.lblPulgadas.AutoSize = true;
            this.lblPulgadas.Location = new System.Drawing.Point(48, 178);
            this.lblPulgadas.Name = "lblPulgadas";
            this.lblPulgadas.Size = new System.Drawing.Size(73, 20);
            this.lblPulgadas.TabIndex = 5;
            this.lblPulgadas.Text = "Pulgadas:";
            // 
            // txtPulgadas
            // 
            this.txtPulgadas.Location = new System.Drawing.Point(127, 175);
            this.txtPulgadas.Name = "txtPulgadas";
            this.txtPulgadas.Size = new System.Drawing.Size(100, 27);
            this.txtPulgadas.TabIndex = 6;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(127, 231);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(100, 29);
            this.btnCalcular.TabIndex = 7;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(48, 285);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 20);
            this.lblResultado.TabIndex = 8;
            // 
            // FormEjercicio13
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 345);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtPulgadas);
            this.Controls.Add(this.lblPulgadas);
            this.Controls.Add(this.txtPies);
            this.Controls.Add(this.lblPies);
            this.Controls.Add(this.txtYardas);
            this.Controls.Add(this.lblYardas);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormEjercicio13";
            this.Text = "Convertir Yardas, Pies y Pulgadas a Centímetros";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblYardas;
        private System.Windows.Forms.TextBox txtYardas;
        private System.Windows.Forms.Label lblPies;
        private System.Windows.Forms.TextBox txtPies;
        private System.Windows.Forms.Label lblPulgadas;
        private System.Windows.Forms.TextBox txtPulgadas;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}
