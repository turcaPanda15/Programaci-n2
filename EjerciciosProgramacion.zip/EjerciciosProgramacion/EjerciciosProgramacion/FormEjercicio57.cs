﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio57 : Form
    {
        public FormEjercicio57()
        {
            InitializeComponent();
        }

        private void btnSumar_Click(object sender, EventArgs e)
        {
            // Obtener el número ingresado por el usuario
            int numero = int.Parse(txtNumero.Text);

            // Calcular la suma de los dígitos
            int sumaDigitos = 0;
            while (numero != 0)
            {
                sumaDigitos += numero % 10;
                numero /= 10;
            }

            // Mostrar la suma de los dígitos en el TextBox de resultados
            txtSumaDigitos.Text = sumaDigitos.ToString();
        }
    }
}
