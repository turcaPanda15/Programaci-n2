﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio46 : Form
    {
        private int[] arreglo;

        public FormEjercicio46()
        {
            InitializeComponent();
        }

        private void btnCrearArreglo_Click(object sender, EventArgs e)
        {
            CrearArreglo();
        }

        private void CrearArreglo()
        {
            if (int.TryParse(txtTamano.Text, out int tamano) && tamano > 0)
            {
                arreglo = new int[tamano];
                MessageBox.Show("Arreglo creado correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Ingrese un tamaño válido para el arreglo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnOperacion_Click(object sender, EventArgs e)
        {
            if (arreglo == null || arreglo.Length == 0)
            {
                MessageBox.Show("Primero debe crear el arreglo.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string resultado = "";

            switch (cmbOperacion.SelectedIndex)
            {
                case 0: // Suma de elementos
                    resultado = $"Suma de elementos: {arreglo.Sum()}";
                    break;
                case 1: // Suma de elementos al cuadrado
                    resultado = $"Suma de elementos al cuadrado: {arreglo.Sum(x => x * x)}";
                    break;
                case 2: // Menor elemento y su posición
                    int menor = arreglo.Min();
                    int posicionMenor = Array.IndexOf(arreglo, menor);
                    resultado = $"Menor elemento: {menor}, Posición: {posicionMenor}";
                    break;
                case 3: // Mayor elemento y su posición
                    int mayor = arreglo.Max();
                    int posicionMayor = Array.IndexOf(arreglo, mayor);
                    resultado = $"Mayor elemento: {mayor}, Posición: {posicionMayor}";
                    break;
                case 4: // Promedio de elementos
                    double promedio = arreglo.Average();
                    resultado = $"Promedio de elementos: {promedio}";
                    break;
                case 5: // Ordenar de forma ascendente
                    Array.Sort(arreglo);
                    resultado = $"Arreglo ordenado de forma ascendente: {string.Join(", ", arreglo)}";
                    break;
                case 6: // Módulo del arreglo
                    int modulo = Math.Abs(arreglo.Sum());
                    resultado = $"Módulo del arreglo: {modulo}";
                    break;
                default:
                    MessageBox.Show("Seleccione una operación válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
            }

            MessageBox.Show(resultado, "Resultado de la operación", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
