﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio30 : Form
    {
        public FormEjercicio30()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                int x = int.Parse(txtNumeroX.Text);
                int y = int.Parse(txtNumeroY.Text);

                string resultado = "";

                if (x < 0 && y < 0)
                {
                    resultado = $"(-{x}, -{y}) -> Suma de los cuadrados: {x * x + y * y}";
                }
                else if (x < 0 && y >= 0)
                {
                    resultado = $"(-{x}, {y}) -> Resta: {y - x}";
                }
                else if (x >= 0 && y < 0)
                {
                    if (y != 0)
                        resultado = $"({x}, -{y}) -> División: {x / (double)y}";
                    else
                        resultado = "No se puede dividir por cero.";
                }
                else
                {
                    if (x > y)
                        resultado = $"({x}, {y}) -> Suma: {x + y}";
                    else
                        resultado = $"({x}, {y}) -> Raíz cuadrada de X: {Math.Sqrt(x)}";
                }

                lblResultado.Text = resultado;
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese números enteros válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (DivideByZeroException)
            {
                MessageBox.Show("No se puede dividir entre cero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
