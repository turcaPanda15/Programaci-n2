﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio14 : Form
    {
        public FormEjercicio14()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores ingresados
                double a = double.Parse(txtA.Text);
                double b = double.Parse(txtB.Text);

                // Calcular la solución
                double solucion = -b / a;

                // Mostrar el resultado
                lblSolucion.Text = $"La solución de la ecuación es x = {solucion:F2}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (DivideByZeroException)
            {
                MessageBox.Show("El valor de 'a' no puede ser cero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
