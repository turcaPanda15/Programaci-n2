﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio47
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            lblTamano = new Label();
            txtTamano = new TextBox();
            btnCrearArreglos = new Button();
            cmbOperacion = new ComboBox();
            btnOperacion = new Button();
            lblOperacion = new Label();
            SuspendLayout();
            // 
            // lblTamano
            // 
            lblTamano.AutoSize = true;
            lblTamano.Location = new Point(3, 50);
            lblTamano.Name = "lblTamano";
            lblTamano.Size = new Size(217, 28);
            lblTamano.TabIndex = 0;
            lblTamano.Text = "Tamaño de los arreglos:";
            // 
            // txtTamano
            // 
            txtTamano.Location = new Point(216, 50);
            txtTamano.Name = "txtTamano";
            txtTamano.Size = new Size(100, 34);
            txtTamano.TabIndex = 1;
            // 
            // btnCrearArreglos
            // 
            btnCrearArreglos.Location = new Point(334, 49);
            btnCrearArreglos.Name = "btnCrearArreglos";
            btnCrearArreglos.Size = new Size(104, 35);
            btnCrearArreglos.TabIndex = 2;
            btnCrearArreglos.Text = "Crear Arreglos";
            btnCrearArreglos.UseVisualStyleBackColor = true;
            btnCrearArreglos.Click += btnCrearArreglos_Click;
            // 
            // cmbOperacion
            // 
            cmbOperacion.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbOperacion.FormattingEnabled = true;
            cmbOperacion.Items.AddRange(new object[] { "Producto de puntos", "¿Son ortogonales?", "Calcular Z" });
            cmbOperacion.Location = new Point(228, 100);
            cmbOperacion.Name = "cmbOperacion";
            cmbOperacion.Size = new Size(210, 36);
            cmbOperacion.TabIndex = 3;
            // 
            // btnOperacion
            // 
            btnOperacion.Location = new Point(117, 150);
            btnOperacion.Name = "btnOperacion";
            btnOperacion.Size = new Size(103, 38);
            btnOperacion.TabIndex = 4;
            btnOperacion.Text = "Realizar Operación";
            btnOperacion.UseVisualStyleBackColor = true;
            btnOperacion.Click += btnOperacion_Click;
            // 
            // lblOperacion
            // 
            lblOperacion.AutoSize = true;
            lblOperacion.Location = new Point(3, 100);
            lblOperacion.Name = "lblOperacion";
            lblOperacion.Size = new Size(238, 28);
            lblOperacion.TabIndex = 5;
            lblOperacion.Text = "Seleccione una operación:";
            // 
            // FormEjercicio47
            // 
            AutoScaleDimensions = new SizeF(11F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(450, 200);
            Controls.Add(lblOperacion);
            Controls.Add(btnOperacion);
            Controls.Add(cmbOperacion);
            Controls.Add(btnCrearArreglos);
            Controls.Add(txtTamano);
            Controls.Add(lblTamano);
            Font = new Font("Segoe UI", 12F);
            Margin = new Padding(4, 5, 4, 5);
            Name = "FormEjercicio47";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormEjercicio47";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTamano;
        private System.Windows.Forms.TextBox txtTamano;
        private System.Windows.Forms.Button btnCrearArreglos;
        private System.Windows.Forms.ComboBox cmbOperacion;
        private System.Windows.Forms.Button btnOperacion;
        private System.Windows.Forms.Label lblOperacion;
    }
}
