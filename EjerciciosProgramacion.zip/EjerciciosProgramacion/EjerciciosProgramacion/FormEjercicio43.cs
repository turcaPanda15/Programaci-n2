﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio43 : Form
    {
        public FormEjercicio43()
        {
            InitializeComponent();
        }

        private void btnCalcularPromedio_Click(object sender, EventArgs e)
        {
            CalcularPromedio();
        }

        private void CalcularPromedio()
        {
            lstPromedios.Items.Clear();

            for (int i = 0; i < 25; i++)
            {
                string nombre = Microsoft.VisualBasic.Interaction.InputBox($"Ingrese el nombre del estudiante {i + 1}:", "Nombre", "");
                double nota1 = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox($"Ingrese la nota 1 del estudiante {nombre}:", "Nota 1", ""));
                double nota2 = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox($"Ingrese la nota 2 del estudiante {nombre}:", "Nota 2", ""));
                double nota3 = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox($"Ingrese la nota 3 del estudiante {nombre}:", "Nota 3", ""));

                double promedio = (nota1 + nota2 + nota3) / 3;

                lstPromedios.Items.Add($"Estudiante: {nombre} - Promedio: {promedio:F2}");
            }
        }
    }
}
