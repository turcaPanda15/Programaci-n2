﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblMasa = new System.Windows.Forms.Label();
            this.txtMasa = new System.Windows.Forms.TextBox();
            this.lblAceleracion = new System.Windows.Forms.Label();
            this.txtAceleracion = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(120, 25);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(244, 28);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Calcular Fuerza de un Cuerpo";
            // 
            // lblMasa
            // 
            this.lblMasa.AutoSize = true;
            this.lblMasa.Location = new System.Drawing.Point(45, 81);
            this.lblMasa.Name = "lblMasa";
            this.lblMasa.Size = new System.Drawing.Size(46, 20);
            this.lblMasa.TabIndex = 1;
            this.lblMasa.Text = "Masa:";
            // 
            // txtMasa
            // 
            this.txtMasa.Location = new System.Drawing.Point(97, 78);
            this.txtMasa.Name = "txtMasa";
            this.txtMasa.Size = new System.Drawing.Size(100, 27);
            this.txtMasa.TabIndex = 2;
            // 
            // lblAceleracion
            // 
            this.lblAceleracion.AutoSize = true;
            this.lblAceleracion.Location = new System.Drawing.Point(45, 130);
            this.lblAceleracion.Name = "lblAceleracion";
            this.lblAceleracion.Size = new System.Drawing.Size(88, 20);
            this.lblAceleracion.TabIndex = 3;
            this.lblAceleracion.Text = "Aceleración:";
            // 
            // txtAceleracion
            // 
            this.txtAceleracion.Location = new System.Drawing.Point(139, 127);
            this.txtAceleracion.Name = "txtAceleracion";
            this.txtAceleracion.Size = new System.Drawing.Size(100, 27);
            this.txtAceleracion.TabIndex = 4;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(97, 180);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(100, 29);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(45, 233);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 20);
            this.lblResultado.TabIndex = 6;
            // 
            // FormEjercicio10
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 304);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtAceleracion);
            this.Controls.Add(this.lblAceleracion);
            this.Controls.Add(this.txtMasa);
            this.Controls.Add(this.lblMasa);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormEjercicio10";
            this.Text = "Calcular Fuerza de un Cuerpo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblMasa;
        private System.Windows.Forms.TextBox txtMasa;
        private System.Windows.Forms.Label lblAceleracion;
        private System.Windows.Forms.TextBox txtAceleracion;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}
