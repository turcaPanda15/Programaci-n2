﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio47 : Form
    {
        private int[] arregloA;
        private int[] arregloB;

        public FormEjercicio47()
        {
            InitializeComponent();
        }

        private void btnCrearArreglos_Click(object sender, EventArgs e)
        {
            CrearArreglos();
        }

        private void CrearArreglos()
        {
            if (int.TryParse(txtTamano.Text, out int tamano) && tamano > 0)
            {
                arregloA = new int[tamano];
                arregloB = new int[tamano];
                MessageBox.Show("Arreglos creados correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Ingrese un tamaño válido para los arreglos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnOperacion_Click(object sender, EventArgs e)
        {
            if (arregloA == null || arregloA.Length == 0 || arregloB == null || arregloB.Length == 0)
            {
                MessageBox.Show("Primero debe crear los arreglos.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            switch (cmbOperacion.SelectedIndex)
            {
                case 0: // Producto de puntos
                    int productoPuntos = Enumerable.Range(0, arregloA.Length).Sum(i => arregloA[i] * arregloB[i]);
                    MessageBox.Show($"El producto de puntos es: {productoPuntos}", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                case 1: // Son ortogonales
                    bool ortogonales = Enumerable.Range(0, arregloA.Length).All(i => arregloA[i] * arregloB[i] == 0);
                    MessageBox.Show($"Los arreglos {(ortogonales ? "sí" : "no")} son ortogonales.", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                case 2: // Obtener la expresión Z
                    double productoArreglos = Enumerable.Range(0, arregloA.Length).Aggregate(1, (acc, i) => acc * (arregloA[i] * arregloB[i]));
                    double moduloA = Math.Sqrt(arregloA.Select(x => x * x).Sum());
                    double moduloB = Math.Sqrt(arregloB.Select(x => x * x).Sum());
                    double z = productoArreglos / (moduloA * moduloB);
                    MessageBox.Show($"El valor de Z es: {z}", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                default:
                    MessageBox.Show("Seleccione una operación válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
            }
        }
    }
}
