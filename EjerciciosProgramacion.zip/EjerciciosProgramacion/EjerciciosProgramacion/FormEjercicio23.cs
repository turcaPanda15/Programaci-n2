﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio23 : Form
    {
        public FormEjercicio23()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener la calificación ingresada
                double calificacion = double.Parse(txtCalificacion.Text);

                // Verificar si está aprobado o reprobado
                if (calificacion >= 60)
                {
                    lblResultado.Text = "Aprobado";
                }
                else
                {
                    lblResultado.Text = "Reprobado";
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese una calificación válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
