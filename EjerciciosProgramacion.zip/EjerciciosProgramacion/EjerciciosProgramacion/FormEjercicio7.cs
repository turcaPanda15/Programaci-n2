﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio7 : Form
    {
        public FormEjercicio7()
        {
            InitializeComponent();
        }

        private void btnConvertir_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los grados Fahrenheit ingresados
                double fahrenheit = double.Parse(txtFahrenheit.Text);

                // Convertir grados Fahrenheit a grados Celsius
                double celsius = (5.0 / 9.0) * (fahrenheit - 32);

                // Mostrar el resultado
                lblResultado.Text = $"{fahrenheit} grados Fahrenheit equivalen a {celsius:F2} grados Celsius";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un valor numérico válido para los grados Fahrenheit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
