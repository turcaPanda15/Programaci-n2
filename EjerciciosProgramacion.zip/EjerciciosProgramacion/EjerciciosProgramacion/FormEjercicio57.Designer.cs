﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio57
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumero = new Label();
            txtNumero = new TextBox();
            btnSumar = new Button();
            lblSumaDigitos = new Label();
            txtSumaDigitos = new TextBox();
            SuspendLayout();
            // 
            // lblNumero
            // 
            lblNumero.AutoSize = true;
            lblNumero.Location = new Point(11, 15);
            lblNumero.Name = "lblNumero";
            lblNumero.Size = new Size(135, 20);
            lblNumero.TabIndex = 0;
            lblNumero.Text = "Ingrese un número:";
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(152, 12);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(178, 27);
            txtNumero.TabIndex = 1;
            // 
            // btnSumar
            // 
            btnSumar.Location = new Point(33, 45);
            btnSumar.Name = "btnSumar";
            btnSumar.Size = new Size(285, 35);
            btnSumar.TabIndex = 2;
            btnSumar.Text = "Sumar Dígitos";
            btnSumar.UseVisualStyleBackColor = true;
            btnSumar.Click += btnSumar_Click;
            // 
            // lblSumaDigitos
            // 
            lblSumaDigitos.AutoSize = true;
            lblSumaDigitos.Location = new Point(11, 105);
            lblSumaDigitos.Name = "lblSumaDigitos";
            lblSumaDigitos.Size = new Size(101, 20);
            lblSumaDigitos.TabIndex = 3;
            lblSumaDigitos.Text = "Suma Dígitos:";
            // 
            // txtSumaDigitos
            // 
            txtSumaDigitos.Location = new Point(118, 102);
            txtSumaDigitos.Name = "txtSumaDigitos";
            txtSumaDigitos.ReadOnly = true;
            txtSumaDigitos.Size = new Size(178, 27);
            txtSumaDigitos.TabIndex = 4;
            // 
            // FormEjercicio57
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(364, 153);
            Controls.Add(txtSumaDigitos);
            Controls.Add(lblSumaDigitos);
            Controls.Add(btnSumar);
            Controls.Add(txtNumero);
            Controls.Add(lblNumero);
            Name = "FormEjercicio57";
            Text = "FormEjercicio57";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Button btnSumar;
        private System.Windows.Forms.Label lblSumaDigitos;
        private System.Windows.Forms.TextBox txtSumaDigitos;
    }
}
