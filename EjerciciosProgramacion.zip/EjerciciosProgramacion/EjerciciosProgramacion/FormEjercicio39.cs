﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio39 : Form
    {
        public FormEjercicio39()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            CalcularAprobadosDesaprobados();
        }

        private void CalcularAprobadosDesaprobados()
        {
            string[] notasTexto = txtNotas.Text.Split(',');
            List<int> notas = new List<int>();

            foreach (string notaTexto in notasTexto)
            {
                if (int.TryParse(notaTexto, out int nota))
                {
                    notas.Add(nota);
                }
            }

            int aprobados = 0;
            int desaprobados = 0;

            foreach (int nota in notas)
            {
                if (nota > 60)
                {
                    aprobados++;
                }
                else
                {
                    desaprobados++;
                }
            }

            lblResultados.Text = $"Aprobados: {aprobados}, Desaprobados: {desaprobados}";
        }
    }
}
