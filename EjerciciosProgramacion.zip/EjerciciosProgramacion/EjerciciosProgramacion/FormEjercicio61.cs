﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio61 : Form
    {
        public FormEjercicio61()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Inicializar los primeros dos números de la serie de Fibonacci
            int primero = 0;
            int segundo = 1;

            // Mostrar los dos primeros números de la serie de Fibonacci
            txtResultado.Text = $"{primero}, {segundo}";

            // Calcular y mostrar los siguientes 18 números de la serie de Fibonacci
            for (int i = 2; i < 20; i++)
            {
                int siguiente = primero + segundo;
                txtResultado.Text += $", {siguiente}";
                primero = segundo;
                segundo = siguiente;
            }
        }
    }
}
