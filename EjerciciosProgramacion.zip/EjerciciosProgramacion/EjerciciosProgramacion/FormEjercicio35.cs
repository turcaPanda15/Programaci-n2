﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio35 : Form
    {
        public FormEjercicio35()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Leer los tres números
                double numero1 = double.Parse(txtNumero1.Text);
                double numero2 = double.Parse(txtNumero2.Text);
                double numero3 = double.Parse(txtNumero3.Text);

                // Calcular la suma y el promedio
                double suma = numero1 + numero2 + numero3;
                double promedio = suma / 3;

                // Mostrar los resultados
                lblSuma.Text = "Suma: " + suma.ToString();
                lblPromedio.Text = "Promedio: " + promedio.ToString("F2");
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese números válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
