﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio53
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumeros = new Label();
            txtNumeros = new TextBox();
            btnSumar = new Button();
            lblSumaPares = new Label();
            lblSumaImpares = new Label();
            txtSumaPares = new TextBox();
            txtSumaImpares = new TextBox();
            SuspendLayout();
            // 
            // lblNumeros
            // 
            lblNumeros.AutoSize = true;
            lblNumeros.Location = new Point(11, 15);
            lblNumeros.Name = "lblNumeros";
            lblNumeros.Size = new Size(295, 20);
            lblNumeros.TabIndex = 0;
            lblNumeros.Text = "Ingrese 20 números separados por espacio:";
            // 
            // txtNumeros
            // 
            txtNumeros.Location = new Point(312, 15);
            txtNumeros.Name = "txtNumeros";
            txtNumeros.Size = new Size(356, 27);
            txtNumeros.TabIndex = 1;
            // 
            // btnSumar
            // 
            btnSumar.Location = new Point(75, 48);
            btnSumar.Name = "btnSumar";
            btnSumar.Size = new Size(528, 35);
            btnSumar.TabIndex = 2;
            btnSumar.Text = "Sumar";
            btnSumar.UseVisualStyleBackColor = true;
            btnSumar.Click += btnSumar_Click;
            // 
            // lblSumaPares
            // 
            lblSumaPares.AutoSize = true;
            lblSumaPares.Location = new Point(11, 105);
            lblSumaPares.Name = "lblSumaPares";
            lblSumaPares.Size = new Size(87, 20);
            lblSumaPares.TabIndex = 3;
            lblSumaPares.Text = "Suma Pares:";
            // 
            // lblSumaImpares
            // 
            lblSumaImpares.AutoSize = true;
            lblSumaImpares.Location = new Point(11, 145);
            lblSumaImpares.Name = "lblSumaImpares";
            lblSumaImpares.Size = new Size(106, 20);
            lblSumaImpares.TabIndex = 4;
            lblSumaImpares.Text = "Suma Impares:";
            // 
            // txtSumaPares
            // 
            txtSumaPares.Location = new Point(102, 102);
            txtSumaPares.Name = "txtSumaPares";
            txtSumaPares.ReadOnly = true;
            txtSumaPares.Size = new Size(89, 27);
            txtSumaPares.TabIndex = 5;
            // 
            // txtSumaImpares
            // 
            txtSumaImpares.Location = new Point(104, 142);
            txtSumaImpares.Name = "txtSumaImpares";
            txtSumaImpares.ReadOnly = true;
            txtSumaImpares.Size = new Size(89, 27);
            txtSumaImpares.TabIndex = 6;
            // 
            // FormEjercicio53
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(748, 189);
            Controls.Add(txtSumaImpares);
            Controls.Add(txtSumaPares);
            Controls.Add(lblSumaImpares);
            Controls.Add(lblSumaPares);
            Controls.Add(btnSumar);
            Controls.Add(txtNumeros);
            Controls.Add(lblNumeros);
            Name = "FormEjercicio53";
            Text = "FormEjercicio53";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblNumeros;
        private System.Windows.Forms.TextBox txtNumeros;
        private System.Windows.Forms.Button btnSumar;
        private System.Windows.Forms.Label lblSumaPares;
        private System.Windows.Forms.Label lblSumaImpares;
        private System.Windows.Forms.TextBox txtSumaPares;
        private System.Windows.Forms.TextBox txtSumaImpares;
    }
}
