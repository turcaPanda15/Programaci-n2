﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio44 : Form
    {
        public FormEjercicio44()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            VerificarEdad();
        }

        private void VerificarEdad()
        {
            int edad = Convert.ToInt32(txtEdad.Text);

            if (edad < 13)
            {
                MessageBox.Show("Niño");
            }
            else if (edad <= 25)
            {
                MessageBox.Show("Joven");
            }
            else
            {
                MessageBox.Show("Adulto");
            }
        }
    }
}
