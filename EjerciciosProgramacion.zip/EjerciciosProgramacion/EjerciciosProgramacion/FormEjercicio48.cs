﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio48 : Form
    {
        public FormEjercicio48()
        {
            InitializeComponent();
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            // Obtener la matriz del TextBox
            int[,] matriz = ObtenerMatriz(txtMatriz.Text);

            // Imprimir la matriz en el orden dado
            ImprimirMatriz(matriz, txtResultadoA);

            // Imprimir los elementos sobre la diagonal principal
            ImprimirSobreDiagonalPrincipal(matriz, txtResultadoB);

            // Imprimir los elementos encima de la diagonal principal
            ImprimirEncimaDiagonalPrincipal(matriz, txtResultadoC);

            // Imprimir los elementos por debajo y sobre la diagonal principal
            ImprimirPorDebajoYSobreDiagonalPrincipal(matriz, txtResultadoD);
        }

        private int[,] ObtenerMatriz(string textoMatriz)
        {
            string[] filas = textoMatriz.Trim().Split('\n');
            int filasCount = filas.Length;
            int columnasCount = filas[0].Split(' ').Length;

            int[,] matriz = new int[filasCount, columnasCount];

            for (int i = 0; i < filasCount; i++)
            {
                string[] elementos = filas[i].Trim().Split(' ');
                for (int j = 0; j < columnasCount; j++)
                {
                    matriz[i, j] = int.Parse(elementos[j]);
                }
            }

            return matriz;
        }

        private void ImprimirMatriz(int[,] matriz, TextBox textBox)
        {
            int filas = matriz.GetLength(0);
            int columnas = matriz.GetLength(1);
            string resultado = "";

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    resultado += matriz[i, j] + " ";
                }
                resultado += "\r\n";
            }

            textBox.Text = resultado.Trim();
        }

        private void ImprimirSobreDiagonalPrincipal(int[,] matriz, TextBox textBox)
        {
            int filas = matriz.GetLength(0);
            int columnas = matriz.GetLength(1);
            string resultado = "";

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (j >= i)
                    {
                        resultado += matriz[i, j] + " ";
                    }
                }
            }

            textBox.Text = resultado.Trim();
        }

        private void ImprimirEncimaDiagonalPrincipal(int[,] matriz, TextBox textBox)
        {
            int filas = matriz.GetLength(0);
            int columnas = matriz.GetLength(1);
            string resultado = "";

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (j < i)
                    {
                        resultado += matriz[i, j] + " ";
                    }
                }
            }

            textBox.Text = resultado.Trim();
        }

        private void ImprimirPorDebajoYSobreDiagonalPrincipal(int[,] matriz, TextBox textBox)
        {
            int filas = matriz.GetLength(0);
            int columnas = matriz.GetLength(1);
            string resultado = "";

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (j >= i || j < i)
                    {
                        resultado += matriz[i, j] + " ";
                    }
                }
            }

            textBox.Text = resultado.Trim();
        }
    }
}
