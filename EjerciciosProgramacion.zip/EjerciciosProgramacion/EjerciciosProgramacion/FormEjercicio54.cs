﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio54 : Form
    {
        public FormEjercicio54()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Obtener los números ingresados por el usuario
            string[] numerosStr = txtNumeros.Text.Split(' ');
            double[] numeros = new double[numerosStr.Length];

            // Convertir los números ingresados a doubles
            for (int i = 0; i < numerosStr.Length; i++)
            {
                numeros[i] = double.Parse(numerosStr[i]);
            }

            // Calcular la suma de los números
            double suma = numeros.Sum();

            // Calcular la media aritmética (promedio)
            double media = suma / numeros.Length;

            // Mostrar el resultado
            txtMedia.Text = media.ToString();
        }
    }
}
