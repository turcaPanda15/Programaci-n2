﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio37 : Form
    {
        private int cantidadNumeros;
        private int contadorPares;
        private int contadorImpares;

        public FormEjercicio37()
        {
            InitializeComponent();
        }

        private void btnIngresarNumeros_Click(object sender, EventArgs e)
        {
            try
            {
                cantidadNumeros = int.Parse(txtCantidad.Text);
                contadorPares = 0;
                contadorImpares = 0;
                lstNumeros.Items.Clear();

                for (int i = 0; i < cantidadNumeros; i++)
                {
                    string input = Microsoft.VisualBasic.Interaction.InputBox($"Ingrese el número {i + 1}:", "Ingresar Número", "0");
                    if (int.TryParse(input, out int numero))
                    {
                        lstNumeros.Items.Add(numero);
                        if (numero % 2 == 0)
                        {
                            contadorPares++;
                        }
                        else
                        {
                            contadorImpares++;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        i--;
                    }
                }

                lblPares.Text = "Números Pares: " + contadorPares.ToString();
                lblImpares.Text = "Números Impares: " + contadorImpares.ToString();
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número entero válido para la cantidad de números.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
