﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio24 : Form
    {
        public FormEjercicio24()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el número ingresado
                int a = int.Parse(txtNumero.Text);

                // Calcular Y según la condición
                int y;
                if (a > 0)
                {
                    y = (int)Math.Pow(2, a);
                }
                else
                {
                    y = a + 5;
                }

                // Mostrar resultado
                lblResultado.Text = $"Y = {y}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
