﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio51
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumero = new Label();
            txtNumero = new TextBox();
            btnVerificar = new Button();
            txtResultado = new TextBox();
            SuspendLayout();
            // 
            // lblNumero
            // 
            lblNumero.AutoSize = true;
            lblNumero.Location = new Point(11, 15);
            lblNumero.Name = "lblNumero";
            lblNumero.Size = new Size(135, 20);
            lblNumero.TabIndex = 0;
            lblNumero.Text = "Ingrese un número:";
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(152, 12);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(134, 27);
            txtNumero.TabIndex = 1;
            // 
            // btnVerificar
            // 
            btnVerificar.Location = new Point(23, 56);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(242, 35);
            btnVerificar.TabIndex = 2;
            btnVerificar.Text = "Verificar si es primo";
            btnVerificar.UseVisualStyleBackColor = true;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(11, 107);
            txtResultado.Multiline = true;
            txtResultado.Name = "txtResultado";
            txtResultado.ReadOnly = true;
            txtResultado.ScrollBars = ScrollBars.Vertical;
            txtResultado.Size = new Size(242, 70);
            txtResultado.TabIndex = 3;
            // 
            // FormEjercicio51
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(289, 189);
            Controls.Add(txtResultado);
            Controls.Add(btnVerificar);
            Controls.Add(txtNumero);
            Controls.Add(lblNumero);
            Name = "FormEjercicio51";
            Text = "FormEjercicio51";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtResultado;
    }
}
