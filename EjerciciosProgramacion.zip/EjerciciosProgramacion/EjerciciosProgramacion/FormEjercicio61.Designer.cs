﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio61
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblResultado = new Label();
            txtResultado = new TextBox();
            btnCalcular = new Button();
            SuspendLayout();
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(11, 15);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(78, 20);
            lblResultado.TabIndex = 0;
            lblResultado.Text = "Resultado:";
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(95, 12);
            txtResultado.Multiline = true;
            txtResultado.Name = "txtResultado";
            txtResultado.ReadOnly = true;
            txtResultado.ScrollBars = ScrollBars.Vertical;
            txtResultado.Size = new Size(254, 139);
            txtResultado.TabIndex = 1;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(31, 157);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(318, 35);
            btnCalcular.TabIndex = 2;
            btnCalcular.Text = "Calcular Serie Fibonacci";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // FormEjercicio61
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(421, 204);
            Controls.Add(btnCalcular);
            Controls.Add(txtResultado);
            Controls.Add(lblResultado);
            Name = "FormEjercicio61";
            Text = "FormEjercicio61";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button btnCalcular;
    }
}
