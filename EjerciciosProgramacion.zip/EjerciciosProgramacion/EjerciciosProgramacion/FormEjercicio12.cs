﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio12 : Form
    {
        public FormEjercicio12()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener la cantidad de notas
                int cantidadNotas = int.Parse(txtCantidadNotas.Text);

                // Obtener las notas ingresadas
                string[] notasArray = txtNotas.Text.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                if (notasArray.Length != cantidadNotas)
                {
                    MessageBox.Show($"Por favor, ingrese {cantidadNotas} notas.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Convertir las notas a números
                double[] notas = notasArray.Select(double.Parse).ToArray();

                // Calcular el promedio
                double promedio = notas.Sum() / cantidadNotas;

                // Mostrar el resultado
                lblPromedio.Text = $"El promedio de las notas es: {promedio:F2}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
