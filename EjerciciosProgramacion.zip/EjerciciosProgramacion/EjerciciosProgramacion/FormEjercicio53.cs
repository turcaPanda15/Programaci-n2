﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio53 : Form
    {
        public FormEjercicio53()
        {
            InitializeComponent();
        }

        private void btnSumar_Click(object sender, EventArgs e)
        {
            // Obtener los números ingresados por el usuario
            string[] numerosStr = txtNumeros.Text.Split(' ');
            int[] numeros = new int[numerosStr.Length];

            // Variables para la suma de pares e impares
            int sumaPares = 0, sumaImpares = 0;

            // Convertir los números ingresados a enteros y sumar pares e impares
            foreach (var numeroStr in numerosStr)
            {
                int numero = int.Parse(numeroStr);
                if (numero % 2 == 0)
                {
                    sumaPares += numero;
                }
                else
                {
                    sumaImpares += numero;
                }
            }

            // Mostrar las sumas
            txtSumaPares.Text = sumaPares.ToString();
            txtSumaImpares.Text = sumaImpares.ToString();
        }
    }
}
