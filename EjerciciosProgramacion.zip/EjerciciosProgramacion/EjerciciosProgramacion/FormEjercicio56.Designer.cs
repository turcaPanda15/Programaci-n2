﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio56
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumeros = new Label();
            txtNumeros = new TextBox();
            btnMostrar = new Button();
            lblResultados = new Label();
            txtResultados = new TextBox();
            SuspendLayout();
            // 
            // lblNumeros
            // 
            lblNumeros.AutoSize = true;
            lblNumeros.Location = new Point(11, 15);
            lblNumeros.Name = "lblNumeros";
            lblNumeros.Size = new Size(318, 20);
            lblNumeros.TabIndex = 0;
            lblNumeros.Text = "Ingrese los 20 números separados por espacio:";
            // 
            // txtNumeros
            // 
            txtNumeros.Location = new Point(335, 15);
            txtNumeros.Name = "txtNumeros";
            txtNumeros.Size = new Size(356, 27);
            txtNumeros.TabIndex = 1;
            // 
            // btnMostrar
            // 
            btnMostrar.Location = new Point(88, 48);
            btnMostrar.Name = "btnMostrar";
            btnMostrar.Size = new Size(528, 35);
            btnMostrar.TabIndex = 2;
            btnMostrar.Text = "Mostrar Elementos Múltiplos de 3";
            btnMostrar.UseVisualStyleBackColor = true;
            btnMostrar.Click += btnMostrar_Click;
            // 
            // lblResultados
            // 
            lblResultados.AutoSize = true;
            lblResultados.Location = new Point(11, 105);
            lblResultados.Name = "lblResultados";
            lblResultados.Size = new Size(180, 20);
            lblResultados.TabIndex = 3;
            lblResultados.Text = "Elementos Múltiplos de 3:";
            // 
            // txtResultados
            // 
            txtResultados.Location = new Point(183, 102);
            txtResultados.Multiline = true;
            txtResultados.Name = "txtResultados";
            txtResultados.ReadOnly = true;
            txtResultados.ScrollBars = ScrollBars.Vertical;
            txtResultados.Size = new Size(356, 250);
            txtResultados.TabIndex = 4;
            // 
            // FormEjercicio56
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(702, 364);
            Controls.Add(txtResultados);
            Controls.Add(lblResultados);
            Controls.Add(btnMostrar);
            Controls.Add(txtNumeros);
            Controls.Add(lblNumeros);
            Name = "FormEjercicio56";
            Text = "FormEjercicio56";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblNumeros;
        private System.Windows.Forms.TextBox txtNumeros;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Label lblResultados;
        private System.Windows.Forms.TextBox txtResultados;
    }
}
