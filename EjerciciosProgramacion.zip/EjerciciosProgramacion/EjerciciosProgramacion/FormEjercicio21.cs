﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio21 : Form
    {
        public FormEjercicio21()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el número ingresado
                double x = double.Parse(txtNumero.Text);

                // Calcular la potencia correspondiente
                double potencia;
                if (x < 0)
                {
                    potencia = Math.Pow(x, 4);
                }
                else
                {
                    potencia = Math.Pow(x, 2);
                }

                // Mostrar resultado
                lblResultado.Text = $"La potencia de {x} es: {potencia}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
