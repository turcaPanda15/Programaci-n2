﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio4 : Form
    {
        public FormEjercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el número ingresado
                double numero = double.Parse(txtNumero.Text);

                // Calcular la raíz cuadrada
                double raizCuadrada = Math.Sqrt(numero);

                // Mostrar el resultado
                lblResultado.Text = $"La raíz cuadrada de {numero} es {raizCuadrada:F2}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un valor numérico válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
