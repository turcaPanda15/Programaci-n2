﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio29 : Form
    {
        public FormEjercicio29()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                int numero1 = int.Parse(txtNumero1.Text);
                int numero2 = int.Parse(txtNumero2.Text);

                int diferencia = Math.Abs(numero1 - numero2);

                lblDiferencia.Text = $"Diferencia: {diferencia}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese números enteros válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
