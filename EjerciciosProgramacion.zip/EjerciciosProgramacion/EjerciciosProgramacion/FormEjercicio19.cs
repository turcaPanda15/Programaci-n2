﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio19 : Form
    {
        public FormEjercicio19()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener la edad ingresada
                int edad = int.Parse(txtEdad.Text);

                // Verificar si es votante
                if (edad >= 16)
                {
                    lblResultado.Text = "Es votante.";
                }
                else
                {
                    lblResultado.Text = "No es votante.";
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese una edad válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
