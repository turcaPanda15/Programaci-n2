﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio60 : Form
    {
        private const string respuestaCorrecta = "Masaya"; // La capital del folclore nicaragüense

        private int intentos = 0;

        public FormEjercicio60()
        {
            InitializeComponent();
        }

        private void btnResponder_Click(object sender, EventArgs e)
        {
            string respuestaUsuario = txtRespuesta.Text;

            if (respuestaUsuario.ToLower() == respuestaCorrecta.ToLower())
            {
                MessageBox.Show("¡Respuesta correcta! La capital del folclore nicaragüense es Masaya.", "¡Correcto!");
            }
            else
            {
                intentos++;
                if (intentos >= 3)
                {
                    MessageBox.Show($"¡Lo siento! Has agotado tus intentos. La respuesta correcta es {respuestaCorrecta}.", "¡Respuesta incorrecta!");
                }
                else
                {
                    MessageBox.Show($"¡Respuesta incorrecta! Te quedan {3 - intentos} intentos.", "¡Intenta de nuevo!");
                }
            }
        }
    }
}
