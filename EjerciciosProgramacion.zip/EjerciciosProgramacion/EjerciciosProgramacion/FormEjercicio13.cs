﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio13 : Form
    {
        public FormEjercicio13()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores ingresados
                double yardas = double.Parse(txtYardas.Text);
                double pies = double.Parse(txtPies.Text);
                double pulgadas = double.Parse(txtPulgadas.Text);

                // Convertir a centímetros
                double centimetros = yardas * 91.44 + pies * 30.48 + pulgadas * 2.54;

                // Mostrar el resultado
                lblResultado.Text = $"La longitud total es de {centimetros:F2} centímetros.";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
