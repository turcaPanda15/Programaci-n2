﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio56 : Form
    {
        public FormEjercicio56()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            // Definir un array de una dimensión para almacenar los números
            int[] numeros = new int[20];

            // Leer los números ingresados por el usuario y almacenarlos en el array
            string[] numerosStr = txtNumeros.Text.Split(' ');
            for (int i = 0; i < numeros.Length && i < numerosStr.Length; i++)
            {
                numeros[i] = int.Parse(numerosStr[i]);
            }

            // Mostrar los elementos que contienen números múltiplos de 3
            string elementosMultiplosDe3 = "";
            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] % 3 == 0)
                {
                    elementosMultiplosDe3 += numeros[i] + " ";
                }
            }

            // Mostrar los elementos en el TextBox de resultados
            txtResultados.Text = elementosMultiplosDe3.Trim();
        }
    }
}
