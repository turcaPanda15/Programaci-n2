﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio52 : Form
    {
        public FormEjercicio52()
        {
            InitializeComponent();
        }

        private void btnContar_Click(object sender, EventArgs e)
        {
            // Obtener los números ingresados por el usuario
            string[] numerosStr = txtNumeros.Text.Split(' ');
            int[] numeros = new int[numerosStr.Length];

            // Contadores para positivos, negativos y ceros
            int positivos = 0, negativos = 0, ceros = 0;

            // Convertir los números ingresados a enteros y contar
            for (int i = 0; i < numerosStr.Length; i++)
            {
                numeros[i] = int.Parse(numerosStr[i]);
                if (numeros[i] > 0)
                {
                    positivos++;
                }
                else if (numeros[i] < 0)
                {
                    negativos++;
                }
                else
                {
                    ceros++;
                }
            }

            // Mostrar los resultados
            txtPositivos.Text = positivos.ToString();
            txtNegativos.Text = negativos.ToString();
            txtCeros.Text = ceros.ToString();
        }
    }
}
