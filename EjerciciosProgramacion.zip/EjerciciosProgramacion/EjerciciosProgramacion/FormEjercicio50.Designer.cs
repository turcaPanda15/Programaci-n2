﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio50
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumero = new Label();
            txtNumero = new TextBox();
            btnCalcular = new Button();
            txtResultado = new TextBox();
            SuspendLayout();
            // 
            // lblNumero
            // 
            lblNumero.AutoSize = true;
            lblNumero.Location = new Point(11, 15);
            lblNumero.Name = "lblNumero";
            lblNumero.Size = new Size(135, 20);
            lblNumero.TabIndex = 0;
            lblNumero.Text = "Ingrese un número:";
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(152, 12);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(134, 27);
            txtNumero.TabIndex = 1;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(23, 54);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(242, 35);
            btnCalcular.TabIndex = 2;
            btnCalcular.Text = "Calcular divisores";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(23, 109);
            txtResultado.Multiline = true;
            txtResultado.Name = "txtResultado";
            txtResultado.ReadOnly = true;
            txtResultado.ScrollBars = ScrollBars.Vertical;
            txtResultado.Size = new Size(242, 200);
            txtResultado.TabIndex = 3;
            // 
            // FormEjercicio50
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(308, 321);
            Controls.Add(txtResultado);
            Controls.Add(btnCalcular);
            Controls.Add(txtNumero);
            Controls.Add(lblNumero);
            Name = "FormEjercicio50";
            Text = "FormEjercicio50";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtResultado;
    }
}
