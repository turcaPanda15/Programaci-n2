﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio45 : Form
    {
        List<double> voltajes = new List<double>();

        public FormEjercicio45()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            AgregarVoltaje();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            CalcularEstadisticas();
        }

        private void AgregarVoltaje()
        {
            if (double.TryParse(txtVoltaje.Text, out double voltaje))
            {
                voltajes.Add(voltaje);
                txtVoltaje.Clear();
            }
            else
            {
                MessageBox.Show("Ingrese un valor válido para el voltaje.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CalcularEstadisticas()
        {
            if (voltajes.Count == 0)
            {
                MessageBox.Show("No hay voltajes ingresados para calcular estadísticas.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            double minimo = voltajes.Min();
            double maximo = voltajes.Max();
            double promedio = voltajes.Average();

            MessageBox.Show($"Voltaje mínimo: {minimo}\nVoltaje máximo: {maximo}\nPromedio de voltajes: {promedio}", "Estadísticas de voltajes", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
