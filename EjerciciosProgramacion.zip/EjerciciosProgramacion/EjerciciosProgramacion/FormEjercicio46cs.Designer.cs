﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio46
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            lblTamano = new Label();
            txtTamano = new TextBox();
            btnCrearArreglo = new Button();
            cmbOperacion = new ComboBox();
            btnOperacion = new Button();
            lblOperacion = new Label();
            SuspendLayout();
            // 
            // lblTamano
            // 
            lblTamano.AutoSize = true;
            lblTamano.Location = new Point(0, 50);
            lblTamano.Name = "lblTamano";
            lblTamano.Size = new Size(184, 28);
            lblTamano.TabIndex = 0;
            lblTamano.Text = "Tamaño del arreglo:";
            // 
            // txtTamano
            // 
            txtTamano.Location = new Point(190, 50);
            txtTamano.Name = "txtTamano";
            txtTamano.Size = new Size(100, 34);
            txtTamano.TabIndex = 1;
            // 
            // btnCrearArreglo
            // 
            btnCrearArreglo.Location = new Point(300, 50);
            btnCrearArreglo.Name = "btnCrearArreglo";
            btnCrearArreglo.Size = new Size(100, 44);
            btnCrearArreglo.TabIndex = 2;
            btnCrearArreglo.Text = "Crear Arreglo";
            btnCrearArreglo.UseVisualStyleBackColor = true;
            btnCrearArreglo.Click += btnCrearArreglo_Click;
            // 
            // cmbOperacion
            // 
            cmbOperacion.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbOperacion.FormattingEnabled = true;
            cmbOperacion.Items.AddRange(new object[] { "Suma de elementos", "Suma de elementos al cuadrado", "Menor elemento y su posición", "Mayor elemento y su posición", "Promedio de elementos", "Ordenar de forma ascendente", "Módulo del arreglo" });
            cmbOperacion.Location = new Point(190, 100);
            cmbOperacion.Name = "cmbOperacion";
            cmbOperacion.Size = new Size(210, 36);
            cmbOperacion.TabIndex = 3;
            // 
            // btnOperacion
            // 
            btnOperacion.Location = new Point(100, 150);
            btnOperacion.Name = "btnOperacion";
            btnOperacion.Size = new Size(106, 38);
            btnOperacion.TabIndex = 4;
            btnOperacion.Text = "Realizar";
            btnOperacion.UseVisualStyleBackColor = true;
            btnOperacion.Click += btnOperacion_Click;
            // 
            // lblOperacion
            // 
            lblOperacion.AutoSize = true;
            lblOperacion.Location = new Point(12, 100);
            lblOperacion.Name = "lblOperacion";
            lblOperacion.Size = new Size(107, 28);
            lblOperacion.TabIndex = 5;
            lblOperacion.Text = "Operación:";
            // 
            // FormEjercicio46
            // 
            AutoScaleDimensions = new SizeF(11F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(450, 200);
            Controls.Add(lblOperacion);
            Controls.Add(btnOperacion);
            Controls.Add(cmbOperacion);
            Controls.Add(btnCrearArreglo);
            Controls.Add(txtTamano);
            Controls.Add(lblTamano);
            Font = new Font("Segoe UI", 12F);
            Margin = new Padding(4, 5, 4, 5);
            Name = "FormEjercicio46";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormEjercicio46";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTamano;
        private System.Windows.Forms.TextBox txtTamano;
        private System.Windows.Forms.Button btnCrearArreglo;
        private System.Windows.Forms.ComboBox cmbOperacion;
        private System.Windows.Forms.Button btnOperacion;
        private System.Windows.Forms.Label lblOperacion;
    }
}
