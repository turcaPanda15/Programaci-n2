﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio58
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblNumeros = new Label();
            txtNumeros = new TextBox();
            btnMostrar = new Button();
            lblResultados = new Label();
            txtResultados = new TextBox();
            SuspendLayout();
            // 
            // lblNumeros
            // 
            lblNumeros.AutoSize = true;
            lblNumeros.Location = new Point(11, 15);
            lblNumeros.Name = "lblNumeros";
            lblNumeros.Size = new Size(318, 20);
            lblNumeros.TabIndex = 0;
            lblNumeros.Text = "Ingrese los 20 números separados por espacio:";
            // 
            // txtNumeros
            // 
            txtNumeros.Location = new Point(335, 12);
            txtNumeros.Name = "txtNumeros";
            txtNumeros.Size = new Size(356, 27);
            txtNumeros.TabIndex = 1;
            // 
            // btnMostrar
            // 
            btnMostrar.Location = new Point(78, 45);
            btnMostrar.Name = "btnMostrar";
            btnMostrar.Size = new Size(528, 35);
            btnMostrar.TabIndex = 2;
            btnMostrar.Text = "Mostrar Elementos Múltiplos de 5";
            btnMostrar.UseVisualStyleBackColor = true;
            btnMostrar.Click += btnMostrar_Click;
            // 
            // lblResultados
            // 
            lblResultados.AutoSize = true;
            lblResultados.Location = new Point(11, 105);
            lblResultados.Name = "lblResultados";
            lblResultados.Size = new Size(180, 20);
            lblResultados.TabIndex = 3;
            lblResultados.Text = "Elementos Múltiplos de 5:";
            // 
            // txtResultados
            // 
            txtResultados.Location = new Point(197, 102);
            txtResultados.Multiline = true;
            txtResultados.Name = "txtResultados";
            txtResultados.ReadOnly = true;
            txtResultados.ScrollBars = ScrollBars.Vertical;
            txtResultados.Size = new Size(356, 250);
            txtResultados.TabIndex = 4;
            // 
            // FormEjercicio58
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(698, 364);
            Controls.Add(txtResultados);
            Controls.Add(lblResultados);
            Controls.Add(btnMostrar);
            Controls.Add(txtNumeros);
            Controls.Add(lblNumeros);
            Name = "FormEjercicio58";
            Text = "FormEjercicio58";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblNumeros;
        private System.Windows.Forms.TextBox txtNumeros;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Label lblResultados;
        private System.Windows.Forms.TextBox txtResultados;
    }
}
