﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio36
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.btnIngresarNumeros = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lstNumeros = new System.Windows.Forms.ListBox();
            this.lblSuma = new System.Windows.Forms.Label();
            this.lblPromedio = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(50, 20);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(400, 28);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Leer 'n' Números, Calcular Suma y Promedio";
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.Location = new System.Drawing.Point(50, 70);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(167, 20);
            this.lblCantidad.TabIndex = 1;
            this.lblCantidad.Text = "Cantidad de Números (n):";
            // 
            // txtCantidad
            // 
            this.txtCantidad.Location = new System.Drawing.Point(230, 67);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(100, 27);
            this.txtCantidad.TabIndex = 2;
            // 
            // btnIngresarNumeros
            // 
            this.btnIngresarNumeros.Location = new System.Drawing.Point(340, 65);
            this.btnIngresarNumeros.Name = "btnIngresarNumeros";
            this.btnIngresarNumeros.Size = new System.Drawing.Size(75, 30);
            this.btnIngresarNumeros.TabIndex = 3;
            this.btnIngresarNumeros.Text = "Ingresar";
            this.btnIngresarNumeros.UseVisualStyleBackColor = true;
            this.btnIngresarNumeros.Click += new System.EventHandler(this.btnIngresarNumeros_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(230, 250);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 30);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lstNumeros
            // 
            this.lstNumeros.FormattingEnabled = true;
            this.lstNumeros.ItemHeight = 20;
            this.lstNumeros.Location = new System.Drawing.Point(50, 110);
            this.lstNumeros.Name = "lstNumeros";
            this.lstNumeros.Size = new System.Drawing.Size(200, 124);
            this.lstNumeros.TabIndex = 5;
            // 
            // lblSuma
            // 
            this.lblSuma.AutoSize = true;
            this.lblSuma.Location = new System.Drawing.Point(50, 300);
            this.lblSuma.Name = "lblSuma";
            this.lblSuma.Size = new System.Drawing.Size(49, 20);
            this.lblSuma.TabIndex = 6;
            this.lblSuma.Text = "Suma:";
            // 
            // lblPromedio
            // 
            this.lblPromedio.AutoSize = true;
            this.lblPromedio.Location = new System.Drawing.Point(50, 340);
            this.lblPromedio.Name = "lblPromedio";
            this.lblPromedio.Size = new System.Drawing.Size(78, 20);
            this.lblPromedio.TabIndex = 7;
            this.lblPromedio.Text = "Promedio:";
            // 
            // FormEjercicio36
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 400);
            this.Controls.Add(this.lblPromedio);
            this.Controls.Add(this.lblSuma);
            this.Controls.Add(this.lstNumeros);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.btnIngresarNumeros);
            this.Controls.Add(this.txtCantidad);
            this.Controls.Add(this.lblCantidad);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormEjercicio36";
            this.Text = "Calcular Suma y Promedio de 'n' Números";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.TextBox txtCantidad;
        private System.Windows.Forms.Button btnIngresarNumeros;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.ListBox lstNumeros;
        private System.Windows.Forms.Label lblSuma;
        private System.Windows.Forms.Label lblPromedio;
    }
}
