﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio58 : Form
    {
        public FormEjercicio58()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            int[] numeros = new int[20];

            string[] numerosStr = txtNumeros.Text.Split(' ');
            for (int i = 0; i < numeros.Length && i < numerosStr.Length; i++)
            {
                numeros[i] = int.Parse(numerosStr[i]);
            }

            string elementosMultiplosDe5 = "";
            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] % 5 == 0)
                {
                    elementosMultiplosDe5 += numeros[i] + " ";
                }
            }

            txtResultados.Text = elementosMultiplosDe5.Trim();
        }
    }
}
