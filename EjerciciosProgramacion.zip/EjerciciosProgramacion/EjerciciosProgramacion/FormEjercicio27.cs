﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio27 : Form
    {
        public FormEjercicio27()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                int cantidadPantalones = int.Parse(txtPantalones.Text);
                double costoTotal;

                if (cantidadPantalones > 3)
                {
                    costoTotal = cantidadPantalones * 10;
                }
                else
                {
                    costoTotal = cantidadPantalones * 12;
                }

                lblCostoTotal.Text = $"Costo total: {costoTotal.ToString("C")}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
