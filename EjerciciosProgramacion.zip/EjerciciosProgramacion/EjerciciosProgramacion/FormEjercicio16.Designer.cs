﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio16
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblA = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.lblB = new System.Windows.Forms.Label();
            this.txtB = new System.Windows.Forms.TextBox();
            this.lblC = new System.Windows.Forms.Label();
            this.txtC = new System.Windows.Forms.TextBox();
            this.lblD = new System.Windows.Forms.Label();
            this.txtD = new System.Windows.Forms.TextBox();
            this.lblE = new System.Windows.Forms.Label();
            this.txtE = new System.Windows.Forms.TextBox();
            this.lblF = new System.Windows.Forms.Label();
            this.txtF = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblSolucion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(127, 28);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(396, 28);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Solución de sistema de ecuaciones (Cramer)";
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(25, 81);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(21, 20);
            this.lblA.TabIndex = 1;
            this.lblA.Text = "a:";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(74, 78);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(100, 27);
            this.txtA.TabIndex = 2;
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(25, 124);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(21, 20);
            this.lblB.TabIndex = 3;
            this.lblB.Text = "b:";
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(74, 121);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(100, 27);
            this.txtB.TabIndex = 4;
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(25, 167);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(20, 20);
            this.lblC.TabIndex = 5;
            this.lblC.Text = "c:";
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(74, 164);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(100, 27);
            this.txtC.TabIndex = 6;
            // 
            // lblD
            // 
            this.lblD.AutoSize = true;
            this.lblD.Location = new System.Drawing.Point(240, 81);
            this.lblD.Name = "lblD";
            this.lblD.Size = new System.Drawing.Size(22, 20);
            this.lblD.TabIndex = 7;
            this.lblD.Text = "d:";
            // 
            // txtD
            // 
            this.txtD.Location = new System.Drawing.Point(293, 78);
            this.txtD.Name = "txtD";
            this.txtD.Size = new System.Drawing.Size(100, 27);
            this.txtD.TabIndex = 8;
            // 
            // lblE
            // 
            this.lblE.AutoSize = true;
            this.lblE.Location = new System.Drawing.Point(240, 124);
            this.lblE.Name = "lblE";
            this.lblE.Size = new System.Drawing.Size(20, 20);
            this.lblE.TabIndex = 9;
            this.lblE.Text = "e:";
            // 
            // txtE
            // 
            this.txtE.Location = new System.Drawing.Point(293, 121);
            this.txtE.Name = "txtE";
            this.txtE.Size = new System.Drawing.Size(100, 27);
            this.txtE.TabIndex = 10;
            // 
            // lblF
            // 
            this.lblF.AutoSize = true;
            this.lblF.Location = new System.Drawing.Point(240, 167);
            this.lblF.Name = "lblF";
            this.lblF.Size = new System.Drawing.Size(20, 20);
            this.lblF.TabIndex = 11;
            this.lblF.Text = "f:";
            // 
            // txtF
            // 
            this.txtF.Location = new System.Drawing.Point(293, 164);
            this.txtF.Name = "txtF";
            this.txtF.Size = new System.Drawing.Size(100, 27);
            this.txtF.TabIndex = 12;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(174, 207);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(114, 29);
            this.btnCalcular.TabIndex = 13;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblSolucion
            // 
            this.lblSolucion.AutoSize = true;
            this.lblSolucion.Location = new System.Drawing.Point(25, 253);
            this.lblSolucion.Name = "lblSolucion";
            this.lblSolucion.Size = new System.Drawing.Size(0, 20);
            this.lblSolucion.TabIndex = 14;
            // 
            // FormEjercicio16
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(625, 305);
            this.Controls.Add(this.lblSolucion);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtF);
            this.Controls.Add(this.lblF);
            this.Controls.Add(this.txtE);
            this.Controls.Add(this.lblE);
            this.Controls.Add(this.txtD);
            this.Controls.Add(this.lblD);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormEjercicio16";
            this.Text = "Sistema de ecuaciones (Cramer)";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Label lblD;
        private System.Windows.Forms.TextBox txtD;
        private System.Windows.Forms.Label lblE;
        private System.Windows.Forms.TextBox txtE;
        private System.Windows.Forms.Label lblF;
        private System.Windows.Forms.TextBox txtF;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblSolucion;
    }
}
