﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio42 : Form
    {
        public FormEjercicio42()
        {
            InitializeComponent();
        }

        private void btnProcesar_Click(object sender, EventArgs e)
        {
            ProcesarNumeros();
        }

        private void ProcesarNumeros()
        {
            int sumaPositivos = 0;
            int cantidadNegativos = 0;

            foreach (string item in lstNumeros.Items)
            {
                int numero = int.Parse(item);
                if (numero > 0)
                {
                    sumaPositivos += numero;
                }
                else if (numero < 0)
                {
                    cantidadNegativos++;
                }
            }

            lblResultado.Text = $"La suma de los números positivos es: {sumaPositivos}.";
            lblResultadoNegativos.Text = $"La cantidad de números negativos es: {cantidadNegativos}.";
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero.Text, out int numero) && numero != 0)
            {
                lstNumeros.Items.Add(numero);
                txtNumero.Clear();
                txtNumero.Focus();
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un número distinto de cero.", "Error");
            }
        }
    }
}
