﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio41 : Form
    {
        public FormEjercicio41()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            CalcularProducto();
        }

        private void CalcularProducto()
        {
            if (int.TryParse(txtNumero.Text, out int n))
            {
                double producto = 1;
                for (int i = 0; i < n; i++)
                {
                    string numeroTexto = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el número " + (i + 1), "Número", "");
                    if (double.TryParse(numeroTexto, out double numero))
                    {
                        producto *= numero;
                    }
                    else
                    {
                        MessageBox.Show("Por favor, ingrese un número válido.", "Error");
                        return;
                    }
                }
                lblResultado.Text = "El producto de los números es: " + producto;
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un valor válido para N.", "Error");
            }
        }
    }
}
