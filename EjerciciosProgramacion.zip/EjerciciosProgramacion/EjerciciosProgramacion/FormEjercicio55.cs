﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio55 : Form
    {
        public FormEjercicio55()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            // Definir un array de una dimensión para almacenar los números
            int[] numeros = new int[20];

            // Leer los números ingresados por el usuario y almacenarlos en el array
            string[] numerosStr = txtNumeros.Text.Split(' ');
            for (int i = 0; i < numeros.Length && i < numerosStr.Length; i++)
            {
                numeros[i] = int.Parse(numerosStr[i]);
            }

            // Mostrar los elementos que ocupan posiciones impares
            string elementosImpares = "";
            for (int i = 0; i < numeros.Length; i += 2)
            {
                elementosImpares += numeros[i] + " ";
            }

            // Mostrar los elementos en el TextBox de resultados
            txtResultados.Text = elementosImpares.Trim();
        }
    }
}
