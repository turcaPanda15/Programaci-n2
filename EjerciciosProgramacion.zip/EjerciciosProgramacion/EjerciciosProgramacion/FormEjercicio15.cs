﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio15 : Form
    {
        public FormEjercicio15()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores ingresados
                double a11 = double.Parse(txtA11.Text);
                double a12 = double.Parse(txtA12.Text);
                double a21 = double.Parse(txtA21.Text);
                double a22 = double.Parse(txtA22.Text);

                // Calcular el determinante
                double determinante = a11 * a22 - a12 * a21;

                // Mostrar el resultado
                lblResultado.Text = $"El determinante es: {determinante}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
