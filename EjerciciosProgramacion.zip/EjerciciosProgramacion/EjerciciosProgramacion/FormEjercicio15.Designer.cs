﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio15
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblA11 = new System.Windows.Forms.Label();
            this.txtA11 = new System.Windows.Forms.TextBox();
            this.txtA12 = new System.Windows.Forms.TextBox();
            this.lblA12 = new System.Windows.Forms.Label();
            this.txtA21 = new System.Windows.Forms.TextBox();
            this.lblA21 = new System.Windows.Forms.Label();
            this.txtA22 = new System.Windows.Forms.TextBox();
            this.lblA22 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(127, 28);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(245, 28);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Determinante de 2x2 (det)";
            // 
            // lblA11
            // 
            this.lblA11.AutoSize = true;
            this.lblA11.Location = new System.Drawing.Point(25, 81);
            this.lblA11.Name = "lblA11";
            this.lblA11.Size = new System.Drawing.Size(44, 20);
            this.lblA11.TabIndex = 1;
            this.lblA11.Text = "A[1,1]:";
            // 
            // txtA11
            // 
            this.txtA11.Location = new System.Drawing.Point(86, 78);
            this.txtA11.Name = "txtA11";
            this.txtA11.Size = new System.Drawing.Size(100, 27);
            this.txtA11.TabIndex = 2;
            // 
            // txtA12
            // 
            this.txtA12.Location = new System.Drawing.Point(301, 78);
            this.txtA12.Name = "txtA12";
            this.txtA12.Size = new System.Drawing.Size(100, 27);
            this.txtA12.TabIndex = 4;
            // 
            // lblA12
            // 
            this.lblA12.AutoSize = true;
            this.lblA12.Location = new System.Drawing.Point(240, 81);
            this.lblA12.Name = "lblA12";
            this.lblA12.Size = new System.Drawing.Size(44, 20);
            this.lblA12.TabIndex = 3;
            this.lblA12.Text = "A[1,2]:";
            // 
            // txtA21
            // 
            this.txtA21.Location = new System.Drawing.Point(86, 122);
            this.txtA21.Name = "txtA21";
            this.txtA21.Size = new System.Drawing.Size(100, 27);
            this.txtA21.TabIndex = 6;
            // 
            // lblA21
            // 
            this.lblA21.AutoSize = true;
            this.lblA21.Location = new System.Drawing.Point(25, 125);
            this.lblA21.Name = "lblA21";
            this.lblA21.Size = new System.Drawing.Size(44, 20);
            this.lblA21.TabIndex = 5;
            this.lblA21.Text = "A[2,1]:";
            // 
            // txtA22
            // 
            this.txtA22.Location = new System.Drawing.Point(301, 122);
            this.txtA22.Name = "txtA22";
            this.txtA22.Size = new System.Drawing.Size(100, 27);
            this.txtA22.TabIndex = 8;
            // 
            // lblA22
            // 
            this.lblA22.AutoSize = true;
            this.lblA22.Location = new System.Drawing.Point(240, 125);
            this.lblA22.Name = "lblA22";
            this.lblA22.Size = new System.Drawing.Size(44, 20);
            this.lblA22.TabIndex = 7;
            this.lblA22.Text = "A[2,2]:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(174, 172);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(114, 29);
            this.btnCalcular.TabIndex = 9;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(25, 223);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 20);
            this.lblResultado.TabIndex = 10;
            // 
            // FormEjercicio15
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 265);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtA22);
            this.Controls.Add(this.lblA22);
            this.Controls.Add(this.txtA21);
            this.Controls.Add(this.lblA21);
            this.Controls.Add(this.txtA12);
            this.Controls.Add(this.lblA12);
            this.Controls.Add(this.txtA11);
            this.Controls.Add(this.lblA11);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormEjercicio15";
            this.Text = "Determinante de 2x2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblA11;
        private System.Windows.Forms.TextBox txtA11;
        private System.Windows.Forms.TextBox txtA12;
        private System.Windows.Forms.Label lblA12;
        private System.Windows.Forms.TextBox txtA21;
        private System.Windows.Forms.Label lblA21;
        private System.Windows.Forms.TextBox txtA22;
        private System.Windows.Forms.Label lblA22;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}
