﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio32 : Form
    {
        public FormEjercicio32()
        {
            InitializeComponent();
        }

        private void btnCodificar_Click(object sender, EventArgs e)
        {
            try
            {
                int nota = int.Parse(txtNota.Text);
                string codificacion = "";

                if (nota >= 90)
                    codificacion = "A";
                else if (nota >= 80)
                    codificacion = "B";
                else if (nota >= 70)
                    codificacion = "C";
                else if (nota >= 65)
                    codificacion = "D";
                else
                    codificacion = "E";

                lblResultado.Text = $"La codificación de la nota es: {codificacion}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
