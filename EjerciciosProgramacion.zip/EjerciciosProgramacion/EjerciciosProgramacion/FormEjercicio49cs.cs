﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio49 : Form
    {
        public FormEjercicio49()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Obtener los datos de los textbox y convertirlos a matrices bidimensionales
            int[,] A = ObtenerMatriz(txtMatrizA.Text);
            int[,] B = ObtenerMatriz(txtMatrizB.Text);

            // Realizar los cálculos
            int[,] sumaAB = SumarMatrices(A, B);
            int[,] suma2A_3B = Sumar2A_3B(A, B);

            // Mostrar resultados
            MostrarMatrizEnTextBox(txtResultadoAB, sumaAB);
            MostrarMatrizEnTextBox(txtResultado2A_3B, suma2A_3B);
        }

        private int[,] ObtenerMatriz(string textoMatriz)
        {
            string[] filas = textoMatriz.Trim().Split('\n');
            int filasCount = filas.Length;
            int columnasCount = filas[0].Split(' ').Length;

            int[,] matriz = new int[filasCount, columnasCount];

            for (int i = 0; i < filasCount; i++)
            {
                string[] elementos = filas[i].Trim().Split(' ');
                for (int j = 0; j < columnasCount; j++)
                {
                    matriz[i, j] = int.Parse(elementos[j]);
                }
            }

            return matriz;
        }

        private int[,] SumarMatrices(int[,] A, int[,] B)
        {
            int filas = A.GetLength(0);
            int columnas = A.GetLength(1);
            int[,] suma = new int[filas, columnas];

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    suma[i, j] = A[i, j] + B[i, j];
                }
            }

            return suma;
        }

        private int[,] Sumar2A_3B(int[,] A, int[,] B)
        {
            int filas = A.GetLength(0);
            int columnas = A.GetLength(1);
            int[,] suma = new int[filas, columnas];

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    suma[i, j] = 2 * A[i, j] + 3 * B[i, j];
                }
            }

            return suma;
        }

        private void MostrarMatrizEnTextBox(TextBox textBox, int[,] matriz)
        {
            int filas = matriz.GetLength(0);
            int columnas = matriz.GetLength(1);
            string resultado = "";

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    resultado += matriz[i, j] + " ";
                }
                resultado += "\r\n";
            }

            textBox.Text = resultado.Trim();
        }
    }
}
