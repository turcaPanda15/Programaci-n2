﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio50 : Form
    {
        public FormEjercicio50()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Obtener el número ingresado por el usuario
            int numero = int.Parse(txtNumero.Text);

            // Calcular y mostrar los divisores del número
            MostrarDivisores(numero);
        }

        private void MostrarDivisores(int numero)
        {
            // Limpiar el TextBox antes de mostrar los resultados
            txtResultado.Clear();

            // Mostrar los divisores del número
            txtResultado.AppendText("Divisores de " + numero + ":\n");

            for (int i = 1; i <= numero; i++)
            {
                if (numero % i == 0)
                {
                    txtResultado.AppendText(i + "\n");
                }
            }
        }
    }
}
