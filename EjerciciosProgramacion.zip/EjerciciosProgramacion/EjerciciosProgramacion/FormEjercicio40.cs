﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio40 : Form
    {
        public FormEjercicio40()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            CalcularFactorial();
        }

        private void CalcularFactorial()
        {
            if (int.TryParse(txtNumero.Text, out int numero))
            {
                if (numero < 0)
                {
                    lblResultado.Text = "El número debe ser mayor o igual a cero.";
                }
                else
                {
                    long factorial = 1;
                    for (int i = 1; i <= numero; i++)
                    {
                        factorial *= i;
                    }
                    lblResultado.Text = $"{numero}! = {factorial}";
                }
            }
            else
            {
                lblResultado.Text = "Por favor ingrese un número entero válido.";
            }
        }
    }
}
