﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio59 : Form
    {
        public FormEjercicio59()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int numero = int.Parse(txtNumero.Text);

            int sumaDivisores = 0;
            for (int i = 1; i <= numero / 2; i++)
            {
                if (numero % i == 0)
                {
                    sumaDivisores += i;
                }
            }

            if (sumaDivisores == numero)
            {
                txtResultado.Text = "El número es perfecto.";
            }
            else
            {
                txtResultado.Text = "El número no es perfecto.";
            }
        }
    }
}
