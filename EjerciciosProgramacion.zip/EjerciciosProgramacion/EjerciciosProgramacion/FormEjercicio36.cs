﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio36 : Form
    {
        private int cantidadNumeros;
        private int contador;

        public FormEjercicio36()
        {
            InitializeComponent();
        }

        private void btnIngresarNumeros_Click(object sender, EventArgs e)
        {
            try
            {
                cantidadNumeros = int.Parse(txtCantidad.Text);
                contador = 0;
                lstNumeros.Items.Clear();

                for (int i = 0; i < cantidadNumeros; i++)
                {
                    string input = Microsoft.VisualBasic.Interaction.InputBox($"Ingrese el número {i + 1}:", "Ingresar Número", "0");
                    if (int.TryParse(input, out int numero))
                    {
                        lstNumeros.Items.Add(numero);
                        contador++;
                    }
                    else
                    {
                        MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        i--;
                    }
                }

                if (contador == cantidadNumeros)
                {
                    btnCalcular.Enabled = true;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número entero válido para la cantidad de números.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (contador == cantidadNumeros)
            {
                double suma = 0;
                foreach (var item in lstNumeros.Items)
                {
                    suma += Convert.ToDouble(item);
                }

                double promedio = suma / cantidadNumeros;

                lblSuma.Text = "Suma: " + suma.ToString();
                lblPromedio.Text = "Promedio: " + promedio.ToString("F2");
            }
            else
            {
                MessageBox.Show("Por favor, ingrese todos los números antes de calcular.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
