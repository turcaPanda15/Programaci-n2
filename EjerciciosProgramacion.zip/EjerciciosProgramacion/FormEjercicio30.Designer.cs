﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio30
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblNumeroX = new System.Windows.Forms.Label();
            this.txtNumeroX = new System.Windows.Forms.TextBox();
            this.lblNumeroY = new System.Windows.Forms.Label();
            this.txtNumeroY = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(111, 28);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(195, 28);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Operaciones (Ej. 30)";
            // 
            // lblNumeroX
            // 
            this.lblNumeroX.AutoSize = true;
            this.lblNumeroX.Location = new System.Drawing.Point(25, 81);
            this.lblNumeroX.Name = "lblNumeroX";
            this.lblNumeroX.Size = new System.Drawing.Size(66, 20);
            this.lblNumeroX.TabIndex = 1;
            this.lblNumeroX.Text = "Número X:";
            // 
            // txtNumeroX
            // 
            this.txtNumeroX.Location = new System.Drawing.Point(129, 78);
            this.txtNumeroX.Name = "txtNumeroX";
            this.txtNumeroX.Size = new System.Drawing.Size(100, 27);
            this.txtNumeroX.TabIndex = 2;
            // 
            // lblNumeroY
            // 
            this.lblNumeroY.AutoSize = true;
            this.lblNumeroY.Location = new System.Drawing.Point(25, 125);
            this.lblNumeroY.Name = "lblNumeroY";
            this.lblNumeroY.Size = new System.Drawing.Size(66, 20);
            this.lblNumeroY.TabIndex = 3;
            this.lblNumeroY.Text = "Número Y:";
            // 
            // txtNumeroY
            // 
            this.txtNumeroY.Location = new System.Drawing.Point(129, 122);
            this.txtNumeroY.Name = "txtNumeroY";
            this.txtNumeroY.Size = new System.Drawing.Size(100, 27);
            this.txtNumeroY.TabIndex = 4;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(129, 167);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(100, 29);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(25, 218);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 20);
            this.lblResultado.TabIndex = 6;
            // 
            // FormEjercicio30
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 305);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtNumeroY);
            this.Controls.Add(this.lblNumeroY);
            this.Controls.Add(this.txtNumeroX);
            this.Controls.Add(this.lblNumeroX);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormEjercicio30";
            this.Text = "Operaciones";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblNumeroX;
        private System.Windows.Forms.TextBox txtNumeroX;
        private System.Windows.Forms.Label lblNumeroY;
        private System.Windows.Forms.TextBox txtNumeroY;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}
