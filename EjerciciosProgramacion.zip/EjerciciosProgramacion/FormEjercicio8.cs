﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio8 : Form
    {
        public FormEjercicio8()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los lados del triángulo ingresados
                double lado1 = double.Parse(txtLado1.Text);
                double lado2 = double.Parse(txtLado2.Text);
                double lado3 = double.Parse(txtLado3.Text);

                // Calcular el semiperímetro
                double s = (lado1 + lado2 + lado3) / 2;

                // Calcular el área del triángulo usando la fórmula de Herón
                double area = Math.Sqrt(s * (s - lado1) * (s - lado2) * (s - lado3));

                // Mostrar el resultado
                lblResultado.Text = $"El área del triángulo es {area:F2}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos para los lados del triángulo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
