﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio3 : Form
    {
        // Constante C
        private const double C = 2.5;

        public FormEjercicio3()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el valor de X
                double x = double.Parse(txtX.Text);

                // Calcular el valor de y
                double y = x * C - 2;

                // Mostrar el resultado
                lblResultado.Text = $"Para X = {x}, y = {y:F2}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un valor numérico válido para X.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
