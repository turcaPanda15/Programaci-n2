﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio17 : Form
    {
        public FormEjercicio17()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores ingresados
                double masa = double.Parse(txtMasa.Text);
                double velocidad = double.Parse(txtVelocidad.Text);
                double altura = double.Parse(txtAltura.Text);
                double g = 9.81; // Constante de gravedad

                // Calcular energía cinética
                double energiaCinetica = 0.5 * masa * Math.Pow(velocidad, 2);

                // Calcular energía potencial
                double energiaPotencial = masa * altura * g;

                // Calcular energía total
                double energiaTotal = energiaCinetica + energiaPotencial;

                // Mostrar resultado
                lblEnergiaTotal.Text = $"La energía total es: {energiaTotal} J";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
