﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio18 : Form
    {
        public FormEjercicio18()
        {
            InitializeComponent();
        }

        private void btnInvertir_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el número ingresado
                int numero = int.Parse(txtNumero.Text);

                // Verificar que el número tenga tres cifras
                if (numero < 100 || numero > 999)
                {
                    throw new ArgumentException("El número debe tener tres cifras.");
                }

                // Invertir el número
                int invertido = (numero % 10) * 100 + ((numero / 10) % 10) * 10 + (numero / 100);

                // Mostrar resultado
                lblResultado.Text = $"El número invertido es: {invertido}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
