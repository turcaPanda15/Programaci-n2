﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio26 : Form
    {
        public FormEjercicio26()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = int.Parse(txtNumero.Text);

                // Inciso a) XY
                if (txtNumero.Text.Length == 2)
                {
                    int x = numero / 10;
                    int y = numero % 10;
                    lblResultado.Text = $"X = {x}, Y = {y}";
                }
                // Inciso b) XYZ
                else if (txtNumero.Text.Length == 3)
                {
                    int x = numero / 100;
                    int y = (numero / 10) % 10;
                    int z = numero % 10;
                    lblResultado.Text = $"X = {x}, Y = {y}, Z = {z}";
                }
                // Inciso c) XYZW
                else if (txtNumero.Text.Length == 4)
                {
                    int x = numero / 1000;
                    int y = (numero / 100) % 10;
                    int z = (numero / 10) % 10;
                    int w = numero % 10;
                    lblResultado.Text = $"X = {x}, Y = {y}, Z = {z}, W = {w}";
                }
                else
                {
                    lblResultado.Text = "Por favor, ingrese un número de la longitud correcta.";
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
