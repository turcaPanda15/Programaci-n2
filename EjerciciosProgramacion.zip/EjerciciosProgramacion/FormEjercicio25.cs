﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio25 : Form
    {
        public FormEjercicio25()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el número ingresado
                int numero = int.Parse(txtNumero.Text);

                // Verificar si es divisible por tres
                if (numero % 3 == 0)
                {
                    lblResultado.Text = $"{numero} es divisible por tres.";
                }
                else
                {
                    lblResultado.Text = $"{numero} no es divisible por tres.";
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
