﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio10 : Form
    {
        public FormEjercicio10()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener la masa y la aceleración ingresadas
                double masa = double.Parse(txtMasa.Text);
                double aceleracion = double.Parse(txtAceleracion.Text);

                // Calcular la fuerza del cuerpo
                double fuerza = masa * aceleracion;

                // Mostrar el resultado
                lblResultado.Text = $"La fuerza del cuerpo es {fuerza:F2}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos para la masa y la aceleración.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
