namespace EjerciciosProgramacion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InicializarComboBox();
        }

        private void InicializarComboBox()
        {
            // Agregar los ejercicios al ComboBox
            for (int i = 1; i <= 62; i++)
            {
                cmbEjercicios.Items.Add($"Ejercicio {i}");
            }
        }

        private void cmbEjercicios_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Obtener el ejercicio seleccionado
            string ejercicio = cmbEjercicios.SelectedItem.ToString();

            // Mostrar el formulario correspondiente al ejercicio seleccionado
            MostrarFormularioEjercicio(ejercicio);
        }

        private void MostrarFormularioEjercicio(string ejercicio)
        {
            switch (ejercicio)
            {
                case "Ejercicio 1":
                    MostrarFormularioEjercicio1();
                    break;
                case "Ejercicio 2":
                    MostrarFormularioEjercicio2();
                    break;
                case "Ejercicio 3":
                    MostrarFormularioEjercicio3();
                    break;
                case "Ejercicio 4":
                    MostrarFormularioEjercicio4();
                    break;
                case "Ejercicio 5":
                    MostrarFormularioEjercicio5();
                    break;
                case "Ejercicio 6":
                    MostrarFormularioEjercicio6();
                    break;
                case "Ejercicio 7":
                    MostrarFormularioEjercicio7();
                    break;
                case "Ejercicio 8":
                    MostrarFormularioEjercicio8();
                    break;
                case "Ejercicio 9":
                    MostrarFormularioEjercicio9();
                    break;
                case "Ejercicio 10":
                    MostrarFormularioEjercicio10();
                    break;
                case "Ejercicio 11":
                    MostrarFormularioEjercicio11();
                    break;
                case "Ejercicio 12":
                    MostrarFormularioEjercicio12();
                    break;
                case "Ejercicio 13":
                    MostrarFormularioEjercicio13();
                    break;
                case "Ejercicio 14":
                    MostrarFormularioEjercicio14();
                    break;
                case "Ejercicio 15":
                    MostrarFormularioEjercicio15();
                    break;
                case "Ejercicio 16":
                    MostrarFormularioEjercicio16();
                    break;
                case "Ejercicio 17":
                    MostrarFormularioEjercicio17();
                    break;
                case "Ejercicio 18":
                    MostrarFormularioEjercicio18();
                    break;
                case "Ejercicio 19":
                    MostrarFormularioEjercicio19();
                    break;
                case "Ejercicio 20":
                    MostrarFormularioEjercicio20();
                    break;
                case "Ejercicio 21":
                    MostrarFormularioEjercicio21();
                    break;
                case "Ejercicio 22":
                    MostrarFormularioEjercicio22();
                    break;
                case "Ejercicio 23":
                    MostrarFormularioEjercicio23();
                    break;
                case "Ejercicio 24":
                    MostrarFormularioEjercicio24();
                    break;
                case "Ejercicio 25":
                    MostrarFormularioEjercicio25();
                    break;
                case "Ejercicio 26":
                    MostrarFormularioEjercicio26();
                    break;
                case "Ejercicio 27":
                    MostrarFormularioEjercicio27();
                    break;
                case "Ejercicio 28":
                    MostrarFormularioEjercicio28();
                    break;
                case "Ejercicio 29":
                    MostrarFormularioEjercicio29();
                    break;
                case "Ejercicio 30":
                    MostrarFormularioEjercicio30();
                    break;
                case "Ejercicio 31":
                    MostrarFormularioEjercicio31();
                    break;
                case "Ejercicio 32":
                    MostrarFormularioEjercicio32();
                    break;
                default:
                    MessageBox.Show("No se encontr� el ejercicio correspondiente.");
                    break;
            }
        }

        private void MostrarFormularioEjercicio1()
        {
            FormEjercicio1 form = new FormEjercicio1();
            form.Show();
        }

        private void MostrarFormularioEjercicio2()
        {
            FormEjercicio2 form = new FormEjercicio2();
            form.Show();
        }

        private void MostrarFormularioEjercicio3()
        {
            FormEjercicio3 form = new FormEjercicio3();
            form.Show();
        }

        private void MostrarFormularioEjercicio4()
        {
            FormEjercicio4 form = new FormEjercicio4();
            form.Show();
        }

        private void MostrarFormularioEjercicio5()
        {
            FormEjercicio5 form = new FormEjercicio5();
            form.Show();
        }

        private void MostrarFormularioEjercicio6()
        {
            FormEjercicio6 form = new FormEjercicio6();
            form.Show();
        }

        private void MostrarFormularioEjercicio7()
        {
            FormEjercicio7 form = new FormEjercicio7();
            form.Show();
        }

        private void MostrarFormularioEjercicio8()
        {
            FormEjercicio8 form = new FormEjercicio8();
            form.Show();
        }

        private void MostrarFormularioEjercicio9()
        {
            FormEjercicio9 form = new FormEjercicio9();
            form.Show();
        }

        private void MostrarFormularioEjercicio10()
        {
            FormEjercicio10 form = new FormEjercicio10();
            form.Show();
        }

        private void MostrarFormularioEjercicio11()
        {
            FormEjercicio11 form = new FormEjercicio11();
            form.Show();
        }

        private void MostrarFormularioEjercicio12()
        {
            FormEjercicio12 form = new FormEjercicio12();
            form.Show();
        }

        private void MostrarFormularioEjercicio13()
        {
            FormEjercicio13 form = new FormEjercicio13();
            form.Show();
        }

        private void MostrarFormularioEjercicio14()
        {
            FormEjercicio14 form = new FormEjercicio14();
            form.Show();
        }

        private void MostrarFormularioEjercicio15()
        {
            FormEjercicio15 form = new FormEjercicio15();
            form.Show();
        }

        private void MostrarFormularioEjercicio16()
        {
            FormEjercicio16 form = new FormEjercicio16();
            form.Show();
        }

        private void MostrarFormularioEjercicio17()
        {
            FormEjercicio17 form = new FormEjercicio17();
            form.Show();
        }

        private void MostrarFormularioEjercicio18()
        {
            FormEjercicio18 form = new FormEjercicio18();
            form.Show();
        }

        private void MostrarFormularioEjercicio19()
        {
            FormEjercicio19 form = new FormEjercicio19();
            form.Show();
        }

        private void MostrarFormularioEjercicio20()
        {
            FormEjercicio20 form = new FormEjercicio20();
            form.Show();
        }

        private void MostrarFormularioEjercicio21()
        {
            FormEjercicio21 form = new FormEjercicio21();
            form.Show();
        }

        private void MostrarFormularioEjercicio22()
        {
            FormEjercicio22 form = new FormEjercicio22();
            form.Show();
        }

        private void MostrarFormularioEjercicio23()
        {
            FormEjercicio23 form = new FormEjercicio23();
            form.Show();
        }

        private void MostrarFormularioEjercicio24()
        {
            FormEjercicio24 form = new FormEjercicio24();
            form.Show();
        }

        private void MostrarFormularioEjercicio25()
        {
            FormEjercicio25 form = new FormEjercicio25();
            form.Show();
        }

        private void MostrarFormularioEjercicio26()
        {
            FormEjercicio26 form = new FormEjercicio26();
            form.Show();
        }

        private void MostrarFormularioEjercicio27()
        {
            FormEjercicio27 form = new FormEjercicio27();
            form.Show();
        }

        private void MostrarFormularioEjercicio28()
        {
            FormEjercicio28 form = new FormEjercicio28();
            form.Show();
        }

        private void MostrarFormularioEjercicio29()
        {
            FormEjercicio29 form = new FormEjercicio29();
            form.Show();
        }

        private void MostrarFormularioEjercicio30()
        {
            FormEjercicio30 form = new FormEjercicio30();
            form.Show();
        }

        private void MostrarFormularioEjercicio31()
        {
            FormEjercicio31 form = new FormEjercicio31();
            form.Show();
        }

        private void MostrarFormularioEjercicio32()
        {
            FormEjercicio32 form = new FormEjercicio32();
            form.Show();
        }


        private void btnAbrirForm_Click(object sender, EventArgs e)
        {
            string ejercicio = cmbEjercicios.SelectedItem.ToString();
            MostrarFormularioEjercicio(ejercicio);
        }
    }
}
