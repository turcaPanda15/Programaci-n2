﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio16 : Form
    {
        public FormEjercicio16()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores ingresados
                double a = double.Parse(txtA.Text);
                double b = double.Parse(txtB.Text);
                double c = double.Parse(txtC.Text);
                double d = double.Parse(txtD.Text);
                double ee = double.Parse(txtE.Text);
                double f = double.Parse(txtF.Text);

                // Calcular determinantes
                double determinante = a * ee - b * d;
                double determinanteX = c * ee - b * f;
                double determinanteY = a * f - c * d;

                // Calcular soluciones
                double x = determinanteX / determinante;
                double y = determinanteY / determinante;

                // Mostrar soluciones
                lblSolucion.Text = $"Solución: x = {x}, y = {y}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (DivideByZeroException)
            {
                MessageBox.Show("El determinante no puede ser cero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
