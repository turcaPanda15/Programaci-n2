﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio12
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblCantidadNotas = new System.Windows.Forms.Label();
            this.txtCantidadNotas = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblNotas = new System.Windows.Forms.Label();
            this.txtNotas = new System.Windows.Forms.TextBox();
            this.lblPromedio = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(123, 27);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(184, 28);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Promedio de N Notas";
            // 
            // lblCantidadNotas
            // 
            this.lblCantidadNotas.AutoSize = true;
            this.lblCantidadNotas.Location = new System.Drawing.Point(31, 84);
            this.lblCantidadNotas.Name = "lblCantidadNotas";
            this.lblCantidadNotas.Size = new System.Drawing.Size(157, 20);
            this.lblCantidadNotas.TabIndex = 1;
            this.lblCantidadNotas.Text = "Cantidad de Notas (N):";
            // 
            // txtCantidadNotas
            // 
            this.txtCantidadNotas.Location = new System.Drawing.Point(194, 81);
            this.txtCantidadNotas.Name = "txtCantidadNotas";
            this.txtCantidadNotas.Size = new System.Drawing.Size(100, 27);
            this.txtCantidadNotas.TabIndex = 2;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(148, 132);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(100, 29);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblNotas
            // 
            this.lblNotas.AutoSize = true;
            this.lblNotas.Location = new System.Drawing.Point(31, 184);
            this.lblNotas.Name = "lblNotas";
            this.lblNotas.Size = new System.Drawing.Size(119, 20);
            this.lblNotas.TabIndex = 4;
            this.lblNotas.Text = "Ingrese las Notas:";
            // 
            // txtNotas
            // 
            this.txtNotas.Location = new System.Drawing.Point(156, 181);
            this.txtNotas.Multiline = true;
            this.txtNotas.Name = "txtNotas";
            this.txtNotas.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNotas.Size = new System.Drawing.Size(138, 111);
            this.txtNotas.TabIndex = 5;
            // 
            // lblPromedio
            // 
            this.lblPromedio.AutoSize = true;
            this.lblPromedio.Location = new System.Drawing.Point(31, 319);
            this.lblPromedio.Name = "lblPromedio";
            this.lblPromedio.Size = new System.Drawing.Size(0, 20);
            this.lblPromedio.TabIndex = 6;
            // 
            // FormEjercicio12
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 368);
            this.Controls.Add(this.lblPromedio);
            this.Controls.Add(this.txtNotas);
            this.Controls.Add(this.lblNotas);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtCantidadNotas);
            this.Controls.Add(this.lblCantidadNotas);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormEjercicio12";
            this.Text = "Promedio de N Notas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblCantidadNotas;
        private System.Windows.Forms.TextBox txtCantidadNotas;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblNotas;
        private System.Windows.Forms.TextBox txtNotas;
        private System.Windows.Forms.Label lblPromedio;
    }
}
