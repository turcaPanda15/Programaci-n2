﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio22 : Form
    {
        public FormEjercicio22()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el capital ingresado
                double capital = double.Parse(txtCapital.Text);

                // Calcular el interés según la condición
                double tasa = (capital > 10000) ? 0.07 : 0.06;
                double interes = capital * tasa;

                // Mostrar resultado
                lblResultado.Text = $"Capital: {capital}, Interés: {interes}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un valor válido para el capital.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
