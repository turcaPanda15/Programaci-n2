﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio9 : Form
    {
        public FormEjercicio9()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el radio y la altura del cilindro ingresados
                double radio = double.Parse(txtRadio.Text);
                double altura = double.Parse(txtAltura.Text);

                // Calcular el volumen del cilindro
                double volumen = Math.PI * Math.Pow(radio, 2) * altura;

                // Mostrar el resultado
                lblResultado.Text = $"El volumen del cilindro es {volumen:F2}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos para el radio y la altura del cilindro.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
