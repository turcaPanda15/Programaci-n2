﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio28 : Form
    {
        public FormEjercicio28()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            try
            {
                int numero1 = int.Parse(txtNumero1.Text);
                int numero2 = int.Parse(txtNumero2.Text);

                if ((numero1 > 0 && numero2 < 0) || (numero1 < 0 && numero2 > 0))
                {
                    lblResultado.Text = "Signos opuestos";
                }
                else
                {
                    lblResultado.Text = "No son signos opuestos";
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese números enteros válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
