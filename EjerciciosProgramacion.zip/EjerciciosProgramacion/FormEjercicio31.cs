﻿using System;
using System.Windows.Forms;

namespace EjerciciosProgramacion
{
    public partial class FormEjercicio31 : Form
    {
        public FormEjercicio31()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            try
            {
                double lado1 = double.Parse(txtLado1.Text);
                double lado2 = double.Parse(txtLado2.Text);
                double lado3 = double.Parse(txtLado3.Text);

                string resultado = "";

                if (lado1 == lado2 && lado2 == lado3)
                    resultado = "Triángulo Equilátero";
                else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3)
                    resultado = "Triángulo Isósceles";
                else
                    resultado = "Triángulo Escaleno";

                lblResultado.Text = resultado;
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
