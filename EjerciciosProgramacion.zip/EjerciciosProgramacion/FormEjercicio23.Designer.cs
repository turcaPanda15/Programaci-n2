﻿namespace EjerciciosProgramacion
{
    partial class FormEjercicio23
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitulo = new Label();
            lblCalificacion = new Label();
            txtCalificacion = new TextBox();
            btnVerificar = new Button();
            lblResultado = new Label();
            SuspendLayout();
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblTitulo.Location = new Point(113, 28);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(304, 28);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Aprobado o Reprobado (Ej. 23)";
            // 
            // lblCalificacion
            // 
            lblCalificacion.AutoSize = true;
            lblCalificacion.Location = new Point(22, 81);
            lblCalificacion.Name = "lblCalificacion";
            lblCalificacion.Size = new Size(89, 20);
            lblCalificacion.TabIndex = 1;
            lblCalificacion.Text = "Calificación:";
            // 
            // txtCalificacion
            // 
            txtCalificacion.Location = new Point(115, 78);
            txtCalificacion.Name = "txtCalificacion";
            txtCalificacion.Size = new Size(89, 27);
            txtCalificacion.TabIndex = 2;
            // 
            // btnVerificar
            // 
            btnVerificar.Location = new Point(115, 124);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(89, 29);
            btnVerificar.TabIndex = 3;
            btnVerificar.Text = "Verificar";
            btnVerificar.UseVisualStyleBackColor = true;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(22, 177);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(0, 20);
            lblResultado.TabIndex = 4;
            // 
            // FormEjercicio23
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(430, 305);
            Controls.Add(lblResultado);
            Controls.Add(btnVerificar);
            Controls.Add(txtCalificacion);
            Controls.Add(lblCalificacion);
            Controls.Add(lblTitulo);
            Name = "FormEjercicio23";
            Text = "Aprobado o Reprobado";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblCalificacion;
        private System.Windows.Forms.TextBox txtCalificacion;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lblResultado;
    }
}
